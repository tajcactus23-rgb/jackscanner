package com.bluemeanie.axonscanner.presentation.ui.screens.radar

import android.Manifest
import android.os.Build
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.bluemeanie.axonscanner.domain.model.*
import com.bluemeanie.axonscanner.presentation.ui.theme.BlueMeanieTheme
import com.bluemeanie.axonscanner.presentation.ui.theme.BlueMeanieColors
import com.bluemeanie.axonscanner.presentation.viewmodel.RadarViewModel
import com.bluemeanie.axonscanner.util.ThemeEngine
import kotlin.math.*

@OptIn(ExperimentalTextApi::class)
@Composable
fun RadarScreen(
    viewModel: RadarViewModel = hiltViewModel(),
    onNavigateToFeed: () -> Unit,
    onNavigateToHeatmap: () -> Unit,
    onNavigateToIntel: () -> Unit,
    onNavigateToGear: () -> Unit,
    onNavigateToBtc: () -> Unit
) {
    val radarState by viewModel.radarState.collectAsState()
    val devices by viewModel.devices.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val callsign by viewModel.callsign.collectAsState()
    val showAxonAlert by viewModel.showAxonAlert.collectAsState()
    val colors = BlueMeanieTheme.colors

    var selectedDevice by remember { mutableStateOf<ScannedDevice?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // Header with Status HUD
            RadarHeader(
                callsign = callsign,
                isScanning = radarState.isScanning,
                settings = settings,
                colors = colors
            )

            // Radar Display
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                RadarDisplay(
                    devices = devices.filter { it.lastSeen > System.currentTimeMillis() - 30000 },
                    radarStyle = settings.radarStyle,
                    isScanning = radarState.isScanning,
                    colors = colors,
                    onDeviceClick = { selectedDevice = it }
                )

                // Status Indicators
                StatusIndicators(
                    isScanning = radarState.isScanning,
                    isBluetoothEnabled = viewModel.isBluetoothEnabled,
                    settings = settings,
                    colors = colors,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                )
            }

            // Stats Bar
            StatsBar(
                devicesFound = devices.size,
                axonHits = radarState.axonHits,
                scanDuration = radarState.scanDuration,
                peakRssi = radarState.peakRssi,
                settings = settings,
                colors = colors
            )

            // Scan Button
            ScanButton(
                isScanning = radarState.isScanning,
                buttonStyle = settings.scanButtonStyle,
                buttonColor = settings.scanButtonColor,
                buttonSize = settings.scanButtonSize,
                onClick = {
                    if (radarState.isScanning) viewModel.stopScan() else viewModel.startScan()
                },
                colors = colors
            )

            // Bottom Navigation
            BottomNavigationBar(
                currentRoute = "radar",
                onNavigate = { route ->
                    when (route) {
                        "feed" -> onNavigateToFeed()
                        "heatmap" -> onNavigateToHeatmap()
                        "intel" -> onNavigateToIntel()
                        "gear" -> onNavigateToGear()
                        "btc" -> onNavigateToBtc()
                    }
                },
                colors = colors
            )
        }

        // Axon Alert Overlay
        showAxonAlert?.let { device ->
            AxonAlertOverlay(
                device = device,
                onDismiss = { viewModel.dismissAxonAlert() },
                colors = colors
            )
        }

        // Device Detail Sheet
        selectedDevice?.let { device ->
            DeviceDetailSheet(
                device = device,
                onDismiss = { selectedDevice = null },
                onMarkThreat = { viewModel.markAsThreat(device, it) },
                colors = colors
            )
        }
    }
}

@Composable
fun RadarHeader(
    callsign: String,
    isScanning: Boolean,
    settings: AppSettings,
    colors: BlueMeanieColors
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            // BLUEMEANIE Title with BLUE in blue, MEANIE in red
            Text(
                text = buildAnnotatedString {
                    append("BLUE")
                    addStyle(SpanStyle(color = Color(0xFF3B82F6)), 0, 4)
                    append("MEANIE")
                    addStyle(SpanStyle(color = Color(0xFFEF4444)), 4, 10)
                },
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Row {
                Text(
                    text = "OPS: ",
                    fontSize = 12.sp,
                    color = colors.textMuted
                )
                Text(
                    text = callsign,
                    fontSize = 12.sp,
                    color = colors.primary
                )
                // Hidden easter egg - BM23 in binary, nearly invisible
                Text(
                    text = "01000010 01001101 00110010 00110011",
                    fontSize = 8.sp,
                    color = colors.textMuted.copy(alpha = 0.1f)
                )
            }
        }

        // Scan mode indicator
        ScanModeChip(
            mode = settings.scanMode,
            isScanning = isScanning,
            colors = colors
        )
    }
}

@OptIn(ExperimentalTextApi::class)
@Composable
fun ScanModeChip(
    mode: ScanMode,
    isScanning: Boolean,
    colors: BlueMeanieColors
) {
    val modeName = when (mode) {
        ScanMode.TACTICAL -> "TACTICAL"
        ScanMode.STEALTH -> "STEALTH"
        ScanMode.SWEEP -> "SWEEP"
    }

    var showInfo by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(colors.surface)
            .border(1.dp, colors.primary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .clickable { showInfo = !showInfo }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (isScanning) colors.primary else colors.textMuted)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = modeName,
            fontSize = 12.sp,
            color = colors.textPrimary
        )
        Spacer(modifier = Modifier.width(4.dp))
        Icon(
            imageVector = Icons.Default.Info,
            contentDescription = "Info",
            tint = colors.textMuted,
            modifier = Modifier.size(14.dp)
        )
    }

    if (showInfo) {
        AlertDialog(
            onDismissRequest = { showInfo = false },
            title = { Text("$modeName MODE", color = colors.primary) },
            text = {
                Text(
                    when (mode) {
                        ScanMode.TACTICAL -> "Low latency, full-power continuous scanning. Every Axon advertisement fires a detection the instant it is seen."
                        ScanMode.STEALTH -> "Same full-power detection. Dimmed UI and reduced on-screen activity for discreet use — detection reliability is never reduced."
                        ScanMode.SWEEP -> "Same full-power detection with a sweeping radar presentation. No advertisement is ever missed or delayed."
                    },
                    color = colors.textSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = { showInfo = false }) {
                    Text("UNDERSTOOD", color = colors.primary)
                }
            }
        )
    }
}

private enum class RadarDisplayMode { IDLE, SCANNING, DETECTION }

@Composable
fun RadarDisplay(
    devices: List<ScannedDevice>,
    radarStyle: RadarStyle,
    isScanning: Boolean,
    colors: BlueMeanieColors,
    onDeviceClick: (ScannedDevice) -> Unit
) {
    val hasDetection = devices.any { it.isAxon || it.isThreat }
    val displayMode = when {
        hasDetection && isScanning -> RadarDisplayMode.DETECTION
        isScanning -> RadarDisplayMode.SCANNING
        else -> RadarDisplayMode.IDLE
    }
    val sweepDurationMs = when (displayMode) {
        RadarDisplayMode.IDLE -> 6000; RadarDisplayMode.SCANNING -> 2000; RadarDisplayMode.DETECTION -> 700
    }
    val infiniteTransition = rememberInfiniteTransition(label = "radar")
    val sweepAngle by infiniteTransition.animateFloat(0f, 360f,
        infiniteRepeatable(tween(sweepDurationMs, easing = LinearEasing), RepeatMode.Restart), "sweep")
    val sweepAngle2 by infiniteTransition.animateFloat(360f, 0f,
        infiniteRepeatable(tween((sweepDurationMs * 1.5).toInt(), easing = LinearEasing), RepeatMode.Restart), "sweep2")
    val breathAlpha by infiniteTransition.animateFloat(
        when (displayMode) { RadarDisplayMode.IDLE -> 0.15f; RadarDisplayMode.DETECTION -> 0.5f; else -> 0.6f },
        when (displayMode) { RadarDisplayMode.IDLE -> 0.5f; RadarDisplayMode.DETECTION -> 1.0f; else -> 1.0f },
        infiniteRepeatable(tween(when (displayMode) { RadarDisplayMode.IDLE -> 2500; RadarDisplayMode.DETECTION -> 350; else -> 900 }), RepeatMode.Reverse), "breath")
    val pulseProgress by infiniteTransition.animateFloat(0f, 1f,
        infiniteRepeatable(tween(when (displayMode) { RadarDisplayMode.DETECTION -> 800; RadarDisplayMode.IDLE -> 4000; else -> 2200 }, easing = LinearEasing), RepeatMode.Restart), "p1")
    val pulseProgress2 by infiniteTransition.animateFloat(0.33f, 1.33f,
        infiniteRepeatable(tween(when (displayMode) { RadarDisplayMode.DETECTION -> 800; RadarDisplayMode.IDLE -> 4000; else -> 2200 }, easing = LinearEasing), RepeatMode.Restart), "p2")
    val pulseProgress3 by infiniteTransition.animateFloat(0.66f, 1.66f,
        infiniteRepeatable(tween(when (displayMode) { RadarDisplayMode.DETECTION -> 800; RadarDisplayMode.IDLE -> 4000; else -> 2200 }, easing = LinearEasing), RepeatMode.Restart), "p3")
    val scanLinePos by infiniteTransition.animateFloat(0f, 1f,
        infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart), "scanline")

    val radarColor = when (displayMode) {
        RadarDisplayMode.IDLE -> colors.primary.copy(alpha = 0.4f)
        RadarDisplayMode.SCANNING -> colors.primary
        RadarDisplayMode.DETECTION -> colors.danger
    }
    val ringColor = when (displayMode) {
        RadarDisplayMode.IDLE -> ThemeEngine.RadarRing.copy(alpha = 0.25f)
        RadarDisplayMode.SCANNING -> ThemeEngine.RadarRing
        RadarDisplayMode.DETECTION -> colors.danger.copy(alpha = 0.5f)
    }
    val isSquareStyle = radarStyle == RadarStyle.SQUARE || radarStyle == RadarStyle.CYBERPUNK
    val clipShape = if (isSquareStyle) RoundedCornerShape(16.dp) else CircleShape
    val stateLabel = when (displayMode) {
        RadarDisplayMode.IDLE -> "STANDBY"
        RadarDisplayMode.SCANNING -> if (devices.isEmpty()) "SCANNING…" else "ACTIVE — ${devices.size} DEVICE${if (devices.size != 1) "S" else ""}"
        RadarDisplayMode.DETECTION -> "⚠ THREAT DETECTED ⚠"
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .padding(16.dp)
            .clip(clipShape)
            .background(ThemeEngine.RadarBackground)
            .border(if (displayMode == RadarDisplayMode.DETECTION) 2.dp else 1.dp, radarColor.copy(alpha = breathAlpha), clipShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val radius = size.minDimension / 2f
            val center = Offset(size.width / 2f, size.height / 2f)

            val p1 = pulseProgress.coerceIn(0f, 1f)
            val p2 = pulseProgress2.coerceIn(0f, 1f)
            val p3 = pulseProgress3.coerceIn(0f, 1f)
            when (radarStyle) {
                RadarStyle.TACTICAL -> drawTacticalStyle(center, radius, sweepAngle, breathAlpha, p1, p2, p3, radarColor, ringColor, colors, displayMode, devices)
                RadarStyle.SONAR -> drawSonarStyle(center, radius, sweepAngle, breathAlpha, p1, p2, p3, radarColor, ringColor, colors, displayMode, devices)
                RadarStyle.PULSE -> drawPulseStyle(center, radius, sweepAngle, breathAlpha, p1, p2, p3, radarColor, ringColor, colors, displayMode, devices)
                RadarStyle.GRID -> drawGridStyle(center, radius, sweepAngle, sweepAngle2, breathAlpha, p1, radarColor, ringColor, colors, displayMode, devices)
                RadarStyle.ORBITAL -> drawOrbitalStyle(center, radius, sweepAngle, breathAlpha, p1, p2, radarColor, ringColor, colors, displayMode, devices)
                RadarStyle.CYBERPUNK -> drawCyberpunkStyle(center, radius, size, sweepAngle, sweepAngle2, breathAlpha, p1, scanLinePos, radarColor, ringColor, colors, displayMode, devices)
                RadarStyle.WIREFRAME -> drawWireframeStyle(center, radius, sweepAngle, sweepAngle2, breathAlpha, p1, p2, radarColor, ringColor, colors, displayMode, devices)
                RadarStyle.CONCENTRIC_RINGS -> drawConcentricRingsStyle(center, radius, sweepAngle, sweepAngle2, breathAlpha, p1, p2, p3, radarColor, ringColor, colors, displayMode, devices)
                RadarStyle.SQUARE -> drawSquareStyle(center, radius, size, sweepAngle, breathAlpha, p1, p2, scanLinePos, radarColor, ringColor, colors, displayMode, devices)
            }
            // Device blips — on top of all styles
            devices.forEachIndexed { index, device ->
                val angle = (index * 137.5f) % 360f
                val distance = 0.3f + (device.rssi + 100) / 100f * 0.5f
                val devR = radius * distance.coerceIn(0.15f, 0.88f)
                val rad = Math.toRadians(angle.toDouble())
                val x = center.x + (devR * cos(rad)).toFloat()
                val y = center.y + (devR * sin(rad)).toFloat()
                val dotColor = when {
                    device.isThreat || device.isAxon -> colors.danger
                    device.deviceType == DeviceType.BODY_CAM -> colors.bodyCam
                    device.deviceType == DeviceType.TASER -> colors.taser
                    device.deviceType == DeviceType.FLEX -> colors.flex
                    else -> colors.textMuted
                }
                val blipAlpha = if (displayMode == RadarDisplayMode.DETECTION && (device.isAxon || device.isThreat)) breathAlpha else 1f
                drawCircle(dotColor.copy(alpha = 0.2f * blipAlpha), 20f, Offset(x, y))
                drawCircle(dotColor.copy(alpha = 0.55f * blipAlpha), 10f, Offset(x, y))
                drawCircle(dotColor.copy(alpha = blipAlpha), 5f, Offset(x, y))
                if (device.isAxon || device.isThreat) {
                    drawCircle(dotColor.copy(alpha = 0.4f * blipAlpha), 28f, Offset(x, y), style = Stroke(1.5f))
                }
            }
            // Center origin
            drawCircle(radarColor.copy(alpha = breathAlpha), 5f, center)
            drawCircle(radarColor.copy(alpha = 0.25f * breathAlpha), 12f, center)
        }

        // State label
        Text(stateLabel, fontSize = 9.sp, color = radarColor.copy(alpha = breathAlpha),
            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp))

        // Detection corner brackets
        if (displayMode == RadarDisplayMode.DETECTION) {
            listOf(Alignment.TopStart, Alignment.TopEnd, Alignment.BottomStart, Alignment.BottomEnd).forEach { alignment ->
                Box(modifier = Modifier.align(alignment).padding(8.dp)) {
                    Canvas(modifier = Modifier.size(20.dp)) {
                        val bSz = size.width; val arm = bSz * 0.5f; val sw = 3f
                        val isLeft = alignment == Alignment.TopStart || alignment == Alignment.BottomStart
                        val isTop = alignment == Alignment.TopStart || alignment == Alignment.TopEnd
                        val x0 = if (isLeft) 0f else bSz; val y0 = if (isTop) 0f else bSz
                        val xDir = if (isLeft) arm else -arm; val yDir = if (isTop) arm else -arm
                        drawLine(radarColor.copy(alpha = breathAlpha), Offset(x0, y0), Offset(x0 + xDir, y0), sw)
                        drawLine(radarColor.copy(alpha = breathAlpha), Offset(x0, y0), Offset(x0, y0 + yDir), sw)
                    }
                }
            }
        }

        Text("10m", fontSize = 7.sp, color = colors.textMuted.copy(alpha = 0.4f),
            modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
        Text("30m", fontSize = 7.sp, color = colors.textMuted.copy(alpha = 0.4f),
            modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp))
    }
}

// ─── TACTICAL ────────────────────────────────────────────────────────────────
private fun DrawScope.drawTacticalStyle(center: Offset, radius: Float, sweepAngle: Float, breathAlpha: Float, p1: Float, p2: Float, p3: Float, radarColor: Color, ringColor: Color, colors: BlueMeanieColors, mode: RadarDisplayMode, devices: List<ScannedDevice>) {
    for (i in 1..4) drawCircle(ringColor.copy(alpha = 0.3f), radius * (i / 4f), center, style = Stroke(if (i == 2) 1.5f else 0.8f))
    drawLine(ringColor.copy(alpha = 0.2f), Offset(center.x, 0f), Offset(center.x, size.height), 0.7f)
    drawLine(ringColor.copy(alpha = 0.2f), Offset(0f, center.y), Offset(size.width, center.y), 0.7f)
    if (mode != RadarDisplayMode.IDLE) {
        for (trail in 0..14) {
            val a = (1f - trail / 14f) * 0.5f * breathAlpha
            val w = (16f - trail).coerceAtLeast(1f)
            rotate(sweepAngle - trail * 5f, pivot = center) { drawLine(radarColor.copy(alpha = a), center, Offset(center.x, center.y - radius), w) }
        }
        rotate(sweepAngle, pivot = center) { drawLine(radarColor.copy(alpha = breathAlpha), center, Offset(center.x, center.y - radius), 2.5f) }
    } else {
        rotate(sweepAngle, pivot = center) { drawLine(radarColor.copy(alpha = breathAlpha * 0.5f), center, Offset(center.x, center.y - radius), 1.5f) }
    }
    when (mode) {
        RadarDisplayMode.DETECTION -> for ((p, a) in listOf(p1 to 0.9f, p2 to 0.6f, p3 to 0.3f)) drawCircle(radarColor.copy(alpha = (1f - p) * a * breathAlpha), radius * p, center, style = Stroke(3f))
        RadarDisplayMode.SCANNING -> drawCircle(radarColor.copy(alpha = (1f - p1) * 0.5f), radius * p1, center, style = Stroke(2f))
        else -> {}
    }
}

// ─── SONAR ───────────────────────────────────────────────────────────────────
private fun DrawScope.drawSonarStyle(center: Offset, radius: Float, sweepAngle: Float, breathAlpha: Float, p1: Float, p2: Float, p3: Float, radarColor: Color, ringColor: Color, colors: BlueMeanieColors, mode: RadarDisplayMode, devices: List<ScannedDevice>) {
    for (i in 1..5) drawCircle(ringColor.copy(alpha = 0.18f), radius * (i / 5f), center, style = Stroke(0.6f))
    when (mode) {
        RadarDisplayMode.IDLE -> drawCircle(radarColor.copy(alpha = breathAlpha * 0.6f), radius * 0.5f, center, style = Stroke(1.5f))
        RadarDisplayMode.SCANNING -> {
            for ((p, a) in listOf(p1 to 0.8f, p2 to 0.55f, p3 to 0.3f)) {
                val w = (4f - p * 3f).coerceAtLeast(0.5f)
                drawCircle(radarColor.copy(alpha = (1f - p) * a * breathAlpha), radius * p, center, style = Stroke(w))
            }
            rotate(sweepAngle, pivot = center) { drawLine(radarColor.copy(alpha = 0.3f * breathAlpha), center, Offset(center.x, center.y - radius * 0.9f), 1f) }
        }
        RadarDisplayMode.DETECTION -> for ((p, a) in listOf(p1 to 1f, p2 to 0.7f, p3 to 0.4f)) {
            val w = (8f - p * 6f).coerceAtLeast(1f)
            drawCircle(radarColor.copy(alpha = (1f - p) * a * breathAlpha), radius * p, center, style = Stroke(w))
        }
    }
}

// ─── PULSE ───────────────────────────────────────────────────────────────────
private fun DrawScope.drawPulseStyle(center: Offset, radius: Float, sweepAngle: Float, breathAlpha: Float, p1: Float, p2: Float, p3: Float, radarColor: Color, ringColor: Color, colors: BlueMeanieColors, mode: RadarDisplayMode, devices: List<ScannedDevice>) {
    for (i in 1..3) drawCircle(ringColor.copy(alpha = 0.18f), radius * (i / 3f), center, style = Stroke(0.8f))
    drawLine(ringColor.copy(alpha = 0.15f), Offset(center.x, 0f), Offset(center.x, size.height), 0.5f)
    drawLine(ringColor.copy(alpha = 0.15f), Offset(0f, center.y), Offset(size.width, center.y), 0.5f)
    when (mode) {
        RadarDisplayMode.IDLE -> { val r = radius * (0.3f + breathAlpha * 0.2f); drawCircle(radarColor.copy(alpha = breathAlpha * 0.5f), r, center, style = Stroke(5f * breathAlpha)) }
        RadarDisplayMode.SCANNING -> { val w = 22f * (1f - p1); drawCircle(radarColor.copy(alpha = (1f - p1) * 0.3f * breathAlpha), radius * p1 + w * 0.5f, center, style = Stroke(w + 8f)); drawCircle(radarColor.copy(alpha = (1f - p1) * breathAlpha), radius * p1, center, style = Stroke(w)) }
        RadarDisplayMode.DETECTION -> for (p in listOf(p1, p2)) { val w = 30f * (1f - p); drawCircle(radarColor.copy(alpha = (1f - p) * 0.5f * breathAlpha), radius * p + w, center, style = Stroke(w * 0.6f)); drawCircle(radarColor.copy(alpha = (1f - p) * breathAlpha), radius * p, center, style = Stroke(w)) }
    }
}

// ─── GRID ─────────────────────────────────────────────────────────────────────
private fun DrawScope.drawGridStyle(center: Offset, radius: Float, sweepAngle: Float, sweepAngle2: Float, breathAlpha: Float, p1: Float, radarColor: Color, ringColor: Color, colors: BlueMeanieColors, mode: RadarDisplayMode, devices: List<ScannedDevice>) {
    for (i in 1..4) drawCircle(ringColor.copy(alpha = 0.15f), radius * (i / 4f), center, style = Stroke(0.7f))
    for (i in 0..7) { val r = Math.toRadians((i * 45.0)); val o = radius * 0.95f; drawLine(ringColor.copy(alpha = 0.12f), Offset(center.x + (o * cos(r)).toFloat(), center.y + (o * sin(r)).toFloat()), Offset(center.x - (o * cos(r)).toFloat(), center.y - (o * sin(r)).toFloat()), 0.5f) }
    when (mode) {
        RadarDisplayMode.IDLE -> rotate(sweepAngle * 0.3f, pivot = center) { for (i in 0..3) { val r = Math.toRadians((i * 90.0)); drawLine(radarColor.copy(alpha = breathAlpha * 0.4f), Offset(center.x + (radius * 0.1f * cos(r)).toFloat(), center.y + (radius * 0.1f * sin(r)).toFloat()), Offset(center.x + (radius * 0.9f * cos(r)).toFloat(), center.y + (radius * 0.9f * sin(r)).toFloat()), 1f) } }
        RadarDisplayMode.SCANNING -> {
            rotate(sweepAngle, pivot = center) { for (i in 0..7) { val r = Math.toRadians((i * 45.0)); drawLine(radarColor.copy(alpha = (if (i % 2 == 0) 0.5f else 0.25f) * breathAlpha), center, Offset(center.x + (radius * 0.92f * cos(r)).toFloat(), center.y + (radius * 0.92f * sin(r)).toFloat()), 1.5f) } }
            rotate(sweepAngle2, pivot = center) { for (i in 0..3) { val r = Math.toRadians((i * 90.0)); drawLine(radarColor.copy(alpha = 0.3f * breathAlpha), center, Offset(center.x + (radius * 0.8f * cos(r)).toFloat(), center.y + (radius * 0.8f * sin(r)).toFloat()), 2.5f) } }
        }
        RadarDisplayMode.DETECTION -> for (ring in 0..2) rotate(sweepAngle + ring * 30f, pivot = center) { for (i in 0..11) { val r = Math.toRadians((i * 30.0)); drawLine(radarColor.copy(alpha = (0.7f - ring * 0.2f) * breathAlpha), center, Offset(center.x + (radius * (0.95f - ring * 0.2f) * cos(r)).toFloat(), center.y + (radius * (0.95f - ring * 0.2f) * sin(r)).toFloat()), 1.5f - ring * 0.3f) } }
    }
}

// ─── ORBITAL ─────────────────────────────────────────────────────────────────
private fun DrawScope.drawOrbitalStyle(center: Offset, radius: Float, sweepAngle: Float, breathAlpha: Float, p1: Float, p2: Float, radarColor: Color, ringColor: Color, colors: BlueMeanieColors, mode: RadarDisplayMode, devices: List<ScannedDevice>) {
    val rings = listOf(0.3f, 0.55f, 0.8f)
    rings.forEachIndexed { i, frac -> drawCircle(ringColor.copy(alpha = 0.25f + i * 0.05f), radius * frac, center, style = Stroke(0.8f)) }
    when (mode) {
        RadarDisplayMode.IDLE -> { val r = Math.toRadians(sweepAngle.toDouble()); val orR = radius * 0.55f; val x = center.x + (orR * cos(r)).toFloat(); val y = center.y + (orR * sin(r)).toFloat(); drawCircle(radarColor.copy(alpha = breathAlpha * 0.5f), 8f, Offset(x, y)); drawCircle(radarColor.copy(alpha = breathAlpha * 0.2f), 16f, Offset(x, y)) }
        RadarDisplayMode.SCANNING -> { rings.forEachIndexed { ri, frac -> val orR = radius * frac; val cnt = ri * 2 + 3; for (i in 0..cnt) { val r = Math.toRadians((sweepAngle * (1f + ri * 0.3f) + i * (360f / cnt)).toDouble()); val x = center.x + (orR * cos(r)).toFloat(); val y = center.y + (orR * sin(r)).toFloat(); val a = if (i == 0) breathAlpha else breathAlpha * 0.3f; val ds = if (i == 0) 7f else 4f; drawCircle(radarColor.copy(alpha = a * 0.3f), ds * 2, Offset(x, y)); drawCircle(radarColor.copy(alpha = a), ds, Offset(x, y)) } }; rotate(sweepAngle, pivot = center) { drawLine(radarColor.copy(alpha = 0.3f * breathAlpha), center, Offset(center.x, center.y - radius), 1f) } }
        RadarDisplayMode.DETECTION -> { rings.forEachIndexed { ri, frac -> drawCircle(radarColor.copy(alpha = breathAlpha * 0.4f), radius * frac, center, style = Stroke(2f + ri)); val orR = radius * frac; for (i in 0..5) { val r = Math.toRadians((sweepAngle * (2f - ri * 0.4f) + i * 60f).toDouble()); val x = center.x + (orR * cos(r)).toFloat(); val y = center.y + (orR * sin(r)).toFloat(); drawCircle(radarColor.copy(alpha = breathAlpha), 6f, Offset(x, y)); drawCircle(radarColor.copy(alpha = breathAlpha * 0.3f), 14f, Offset(x, y)) } } }
    }
}

// ─── CYBERPUNK ───────────────────────────────────────────────────────────────
private fun DrawScope.drawCyberpunkStyle(center: Offset, radius: Float, sz: androidx.compose.ui.geometry.Size, sweepAngle: Float, sweepAngle2: Float, breathAlpha: Float, p1: Float, scanLinePos: Float, radarColor: Color, ringColor: Color, colors: BlueMeanieColors, mode: RadarDisplayMode, devices: List<ScannedDevice>) {
    val w = sz.width; val h = sz.height
    for (i in 0..8) { val x = w * i / 8; val y = h * i / 8; drawLine(ringColor.copy(alpha = 0.13f), Offset(x, 0f), Offset(x, h), 0.5f); drawLine(ringColor.copy(alpha = 0.13f), Offset(0f, y), Offset(w, y), 0.5f) }
    val bLen = w * 0.12f; val bSw = 2.5f; val bA = breathAlpha * 0.9f
    listOf(Pair(Offset(0f,0f), Pair(Offset(bLen,0f), Offset(0f,bLen))), Pair(Offset(w,0f), Pair(Offset(w-bLen,0f), Offset(w,bLen))), Pair(Offset(0f,h), Pair(Offset(bLen,h), Offset(0f,h-bLen))), Pair(Offset(w,h), Pair(Offset(w-bLen,h), Offset(w,h-bLen)))).forEach { (c, arms) -> drawLine(radarColor.copy(alpha = bA), c, arms.first, bSw); drawLine(radarColor.copy(alpha = bA), c, arms.second, bSw) }
    when (mode) {
        RadarDisplayMode.IDLE -> { drawLine(radarColor.copy(alpha = breathAlpha * 0.4f), Offset(center.x, 0f), Offset(center.x, h), 1f); drawLine(radarColor.copy(alpha = breathAlpha * 0.4f), Offset(0f, center.y), Offset(w, center.y), 1f); drawCircle(radarColor.copy(alpha = breathAlpha * 0.3f), radius * 0.4f, center, style = Stroke(1.5f)) }
        RadarDisplayMode.SCANNING -> {
            val sx = w * scanLinePos; drawLine(radarColor.copy(alpha = breathAlpha * 0.9f), Offset(sx, 0f), Offset(sx, h), 2f); drawLine(radarColor.copy(alpha = breathAlpha * 0.35f), Offset(sx-10f, 0f), Offset(sx-10f, h), 1f); drawLine(radarColor.copy(alpha = breathAlpha * 0.15f), Offset(sx-20f, 0f), Offset(sx-20f, h), 0.8f)
            rotate(sweepAngle, pivot = center) { val d = radius * 0.55f; val path = Path().apply { moveTo(center.x, center.y-d); lineTo(center.x+d, center.y); lineTo(center.x, center.y+d); lineTo(center.x-d, center.y); close() }; drawPath(path, radarColor.copy(alpha = 0.4f * breathAlpha), style = Stroke(1.5f)) }
            drawLine(radarColor.copy(alpha = 0.5f * breathAlpha), Offset(center.x, 0f), Offset(center.x, h), 1f); drawLine(radarColor.copy(alpha = 0.5f * breathAlpha), Offset(0f, center.y), Offset(w, center.y), 1f)
        }
        RadarDisplayMode.DETECTION -> {
            val sx = w * scanLinePos; val sx2 = w * ((scanLinePos + 0.5f) % 1f)
            drawLine(radarColor.copy(alpha = breathAlpha), Offset(sx, 0f), Offset(sx, h), 3f); drawLine(radarColor.copy(alpha = breathAlpha * 0.5f), Offset(sx2, 0f), Offset(sx2, h), 2f)
            val exp = p1 * radius * 0.4f; val lx = center.x - radius * 0.3f - exp; val rx = center.x + radius * 0.3f + exp; val ty = center.y - radius * 0.3f - exp; val by = center.y + radius * 0.3f + exp; val rA = (1f - p1) * breathAlpha
            drawLine(radarColor.copy(alpha = rA), Offset(lx, ty), Offset(rx, ty), 2f); drawLine(radarColor.copy(alpha = rA), Offset(rx, ty), Offset(rx, by), 2f); drawLine(radarColor.copy(alpha = rA), Offset(rx, by), Offset(lx, by), 2f); drawLine(radarColor.copy(alpha = rA), Offset(lx, by), Offset(lx, ty), 2f)
            drawLine(radarColor.copy(alpha = 0.6f * breathAlpha), Offset(center.x, 0f), Offset(center.x, h), 1.5f); drawLine(radarColor.copy(alpha = 0.6f * breathAlpha), Offset(0f, center.y), Offset(w, center.y), 1.5f)
        }
    }
}

// ─── WIREFRAME ───────────────────────────────────────────────────────────────
private fun DrawScope.drawWireframeStyle(center: Offset, radius: Float, sweepAngle: Float, sweepAngle2: Float, breathAlpha: Float, p1: Float, p2: Float, radarColor: Color, ringColor: Color, colors: BlueMeanieColors, mode: RadarDisplayMode, devices: List<ScannedDevice>) {
    fun pts(sides: Int, r: Float, angleDeg: Float) = (0 until sides).map { i -> val a = Math.toRadians((i * 360.0 / sides + angleDeg)); Offset(center.x + (r * cos(a)).toFloat(), center.y + (r * sin(a)).toFloat()) }
    fun drawPoly(p: List<Offset>, c: Color, sw: Float) { for (i in p.indices) drawLine(c, p[i], p[(i+1) % p.size], sw) }
    drawCircle(ringColor.copy(alpha = 0.2f), radius, center, style = Stroke(0.6f))
    val spd = when (mode) { RadarDisplayMode.IDLE -> 0.2f; RadarDisplayMode.SCANNING -> 1f; RadarDisplayMode.DETECTION -> 2.5f }
    val bA = when (mode) { RadarDisplayMode.IDLE -> 0.25f; else -> 0.6f }
    listOf(Triple(3, radius*0.88f, sweepAngle*spd), Triple(4, radius*0.65f, sweepAngle2*spd*0.8f), Triple(5, radius*0.48f, sweepAngle*spd*1.2f), Triple(6, radius*0.30f, sweepAngle2*spd*0.5f), Triple(8, radius*0.85f, sweepAngle2*spd*0.3f)).forEachIndexed { idx, (sides, r, angle) -> val p = pts(sides, r, angle); drawPoly(p, radarColor.copy(alpha = (bA - idx*0.04f).coerceAtLeast(0.1f) * breathAlpha), 1f + idx*0.2f); if (idx < 2 && mode != RadarDisplayMode.IDLE) p.forEach { pt -> drawLine(radarColor.copy(alpha = 0.15f * breathAlpha), center, pt, 0.7f) } }
    if (mode == RadarDisplayMode.DETECTION) { drawPoly(pts(3, radius*0.2f, sweepAngle*3f), radarColor.copy(alpha = breathAlpha), 2.5f); drawCircle(radarColor.copy(alpha = (1f-p1)*breathAlpha), radius*p1, center, style = Stroke(3f)) }
}

// ─── CONCENTRIC RINGS ────────────────────────────────────────────────────────
private fun DrawScope.drawConcentricRingsStyle(center: Offset, radius: Float, sweepAngle: Float, sweepAngle2: Float, breathAlpha: Float, p1: Float, p2: Float, p3: Float, radarColor: Color, ringColor: Color, colors: BlueMeanieColors, mode: RadarDisplayMode, devices: List<ScannedDevice>) {
    val cnt = when (mode) { RadarDisplayMode.IDLE -> 5; RadarDisplayMode.SCANNING -> 8; RadarDisplayMode.DETECTION -> 10 }
    for (i in 1..cnt) { val frac = i / cnt.toFloat(); val a = (0.1f + frac * 0.1f) * (if (mode == RadarDisplayMode.IDLE) 0.4f else 1f); drawCircle(ringColor.copy(alpha = a), radius * frac, center, style = Stroke(0.6f + frac * 0.4f)) }
    drawLine(ringColor.copy(alpha = 0.18f), Offset(center.x, 0f), Offset(center.x, size.height), 0.6f); drawLine(ringColor.copy(alpha = 0.18f), Offset(0f, center.y), Offset(size.width, center.y), 0.6f)
    when (mode) {
        RadarDisplayMode.IDLE -> drawCircle(radarColor.copy(alpha = breathAlpha * 0.5f), radius * 0.6f * breathAlpha, center, style = Stroke(2f))
        RadarDisplayMode.SCANNING -> { for ((p, a) in listOf(p1 to 0.8f, p2 to 0.55f, p3 to 0.3f)) { val w = (5f - p * 4f).coerceAtLeast(0.5f); drawCircle(radarColor.copy(alpha = (1f-p)*a*breathAlpha), radius*p, center, style = Stroke(w)) }; rotate(sweepAngle*0.4f, pivot = center) { for (i in 0..3) { val r = Math.toRadians((i*90.0)); val arcR = radius*(0.4f+i*0.15f); drawLine(radarColor.copy(alpha = 0.2f*breathAlpha), Offset(center.x+(arcR*cos(r)).toFloat(), center.y+(arcR*sin(r)).toFloat()), Offset(center.x+(arcR*cos(r+0.4)).toFloat(), center.y+(arcR*sin(r+0.4)).toFloat()), 3f) } } }
        RadarDisplayMode.DETECTION -> { for ((p, a) in listOf(p1 to 1f, p2 to 0.7f, p3 to 0.4f)) { val w = (10f-p*8f).coerceAtLeast(1f); drawCircle(radarColor.copy(alpha = (1f-p)*a*0.4f*breathAlpha), radius*p+w, center, style = Stroke(w*0.8f)); drawCircle(radarColor.copy(alpha = (1f-p)*a*breathAlpha), radius*p, center, style = Stroke(w)) }; rotate(sweepAngle, pivot = center) { drawLine(radarColor.copy(alpha = 0.8f*breathAlpha), center, Offset(center.x, center.y-radius), 2f) } }
    }
}

// ─── SQUARE ──────────────────────────────────────────────────────────────────
private fun DrawScope.drawSquareStyle(center: Offset, radius: Float, sz: androidx.compose.ui.geometry.Size, sweepAngle: Float, breathAlpha: Float, p1: Float, p2: Float, scanLinePos: Float, radarColor: Color, ringColor: Color, colors: BlueMeanieColors, mode: RadarDisplayMode, devices: List<ScannedDevice>) {
    val w = sz.width; val h = sz.height
    for (i in 0..6) { val x = w*i/6; val y = h*i/6; drawLine(ringColor.copy(alpha = 0.1f), Offset(x,0f), Offset(x,h), 0.5f); drawLine(ringColor.copy(alpha = 0.1f), Offset(0f,y), Offset(w,y), 0.5f) }
    drawLine(ringColor.copy(alpha = 0.07f), Offset(0f,0f), Offset(w,h), 0.5f); drawLine(ringColor.copy(alpha = 0.07f), Offset(w,0f), Offset(0f,h), 0.5f)
    for (i in 1..3) { val ins = radius*(1f-i/3f)*0.7f; val l=ins; val r=w-ins; val t=ins; val b=h-ins; val a=0.18f*i; drawLine(ringColor.copy(alpha=a), Offset(l,t), Offset(r,t), 0.7f); drawLine(ringColor.copy(alpha=a), Offset(r,t), Offset(r,b), 0.7f); drawLine(ringColor.copy(alpha=a), Offset(r,b), Offset(l,b), 0.7f); drawLine(ringColor.copy(alpha=a), Offset(l,b), Offset(l,t), 0.7f) }
    when (mode) {
        RadarDisplayMode.IDLE -> { drawLine(radarColor.copy(alpha = breathAlpha*0.5f), Offset(center.x,0f), Offset(center.x,h), 1.2f); drawLine(radarColor.copy(alpha = breathAlpha*0.5f), Offset(0f,center.y), Offset(w,center.y), 1.2f) }
        RadarDisplayMode.SCANNING -> {
            val sy = h * scanLinePos; drawLine(radarColor.copy(alpha = breathAlpha*0.9f), Offset(0f,sy), Offset(w,sy), 2f); drawLine(radarColor.copy(alpha = breathAlpha*0.35f), Offset(0f,sy-8f), Offset(w,sy-8f), 1f); drawLine(radarColor.copy(alpha = breathAlpha*0.15f), Offset(0f,sy-18f), Offset(w,sy-18f), 0.8f)
            drawLine(radarColor.copy(alpha = 0.4f*breathAlpha), Offset(center.x,0f), Offset(center.x,h), 1f); drawLine(radarColor.copy(alpha = 0.4f*breathAlpha), Offset(0f,center.y), Offset(w,center.y), 1f)
            rotate(sweepAngle*0.5f, pivot = center) { drawLine(radarColor.copy(alpha = 0.2f*breathAlpha), Offset(center.x, center.y-radius*0.8f), Offset(center.x, center.y+radius*0.8f), 1f); drawLine(radarColor.copy(alpha = 0.2f*breathAlpha), Offset(center.x-radius*0.8f, center.y), Offset(center.x+radius*0.8f, center.y), 1f) }
        }
        RadarDisplayMode.DETECTION -> {
            val sy = h*scanLinePos; val sy2 = h*((scanLinePos+0.5f)%1f); drawLine(radarColor.copy(alpha = breathAlpha), Offset(0f,sy), Offset(w,sy), 3f); drawLine(radarColor.copy(alpha = breathAlpha*0.6f), Offset(0f,sy2), Offset(w,sy2), 2f)
            drawLine(radarColor.copy(alpha = 0.8f*breathAlpha), Offset(center.x,0f), Offset(center.x,h), 1.5f); drawLine(radarColor.copy(alpha = 0.8f*breathAlpha), Offset(0f,center.y), Offset(w,center.y), 1.5f)
            val exp = p1*radius; val sq = radius*0.25f+exp; val lx=center.x-sq; val rx=center.x+sq; val ty=center.y-sq; val by=center.y+sq; val sA=(1f-p1)*breathAlpha
            drawLine(radarColor.copy(alpha=sA), Offset(lx,ty), Offset(rx,ty), 2f); drawLine(radarColor.copy(alpha=sA), Offset(rx,ty), Offset(rx,by), 2f); drawLine(radarColor.copy(alpha=sA), Offset(rx,by), Offset(lx,by), 2f); drawLine(radarColor.copy(alpha=sA), Offset(lx,by), Offset(lx,ty), 2f)
        }
    }
}

@Composable
fun StatusIndicators(
    isScanning: Boolean,
    isBluetoothEnabled: Boolean,
    settings: AppSettings,
    colors: BlueMeanieColors,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(colors.surface.copy(alpha = 0.8f))
            .padding(8.dp)
    ) {
        StatusIndicator(
            label = "BLE",
            isActive = isBluetoothEnabled,
            isWarning = !isBluetoothEnabled,
            colors = colors
        )
        StatusIndicator(
            label = "SCAN",
            isActive = isScanning,
            isWarning = false,
            colors = colors
        )
        StatusIndicator(
            label = "NTFY",
            isActive = settings.notificationsEnabled,
            isWarning = !settings.notificationsEnabled,
            colors = colors
        )
        StatusIndicator(
            label = "DB",
            isActive = true,
            isWarning = false,
            colors = colors
        )
    }
}

@Composable
fun StatusIndicator(
    label: String,
    isActive: Boolean,
    isWarning: Boolean,
    colors: BlueMeanieColors
) {
    val infiniteTransition = rememberInfiniteTransition(label = "indicator")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(500),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Row(
        modifier = Modifier.padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(
                    when {
                        isWarning -> colors.danger
                        isActive -> colors.success
                        else -> colors.textMuted
                    }
                )
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 8.sp,
            color = if (isActive || isWarning) colors.textPrimary else colors.textMuted
        )
    }
}

@Composable
fun StatsBar(
    devicesFound: Int,
    axonHits: Int,
    scanDuration: Long,
    peakRssi: Int,
    settings: AppSettings,
    colors: BlueMeanieColors
) {
    val counterFontSize = when (settings.counterSize) {
        CounterSize.SMALL -> 24.sp
        CounterSize.MEDIUM -> 32.sp
        CounterSize.LARGE -> 40.sp
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        StatItem(
            label = "DEVICES",
            value = devicesFound.toString(),
            color = colors.primary,
            fontSize = counterFontSize,
            colors = colors
        )
        StatItem(
            label = "AXON HITS",
            value = axonHits.toString(),
            color = colors.danger,
            fontSize = counterFontSize,
            colors = colors
        )
        StatItem(
            label = "DURATION",
            value = formatDuration(scanDuration),
            color = colors.warning,
            fontSize = counterFontSize,
            colors = colors
        )
        StatItem(
            label = "SIGNAL PEAK",
            value = "${peakRssi}dBm",
            color = colors.success,
            fontSize = counterFontSize,
            colors = colors
        )
    }
}

@Composable
fun StatItem(
    label: String,
    value: String,
    color: Color,
    fontSize: androidx.compose.ui.unit.TextUnit,
    colors: BlueMeanieColors
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            fontSize = fontSize,
            fontWeight = FontWeight.Bold,
            color = color,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = label,
            fontSize = 8.sp,
            color = colors.textMuted
        )
    }
}

@Composable
fun ScanButton(
    isScanning: Boolean,
    buttonStyle: ScanButtonStyle,
    buttonColor: String,
    buttonSize: ScanButtonSize,
    onClick: () -> Unit,
    colors: BlueMeanieColors
) {
    val buttonSizePx = when (buttonSize) {
        ScanButtonSize.SMALL -> 48.dp
        ScanButtonSize.MEDIUM -> 64.dp
        ScanButtonSize.LARGE -> 80.dp
    }

    val infiniteTransition = rememberInfiniteTransition(label = "button")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isScanning) 1.05f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    val buttonColorParsed = try {
        Color(android.graphics.Color.parseColor(buttonColor))
    } catch (e: Exception) {
        colors.primary
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(buttonSizePx)
                .scale(if (isScanning) scale else 1f)
                .clip(if (buttonStyle == ScanButtonStyle.HEX) {
                    androidx.compose.foundation.shape.GenericShape { size, _ ->
                        val path = Path()
                        val centerX = size.width / 2
                        val centerY = size.height / 2
                        val radius = minOf(size.width, size.height) / 2
                        for (i in 0..5) {
                            val angle = Math.toRadians((i * 60 - 30).toDouble())
                            val x = centerX + (radius * cos(angle)).toFloat()
                            val y = centerY + (radius * sin(angle)).toFloat()
                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        path.close()
                    }
                } else CircleShape)
                .background(
                    if (buttonStyle == ScanButtonStyle.GLOW || buttonStyle == ScanButtonStyle.MILITARY) {
                        Brush.radialGradient(
                            colors = listOf(
                                buttonColorParsed.copy(alpha = 0.8f),
                                buttonColorParsed.copy(alpha = 0.4f),
                                buttonColorParsed.copy(alpha = 0.1f)
                            )
                        )
                    } else {
                        Brush.radialGradient(
                            colors = listOf(
                                buttonColorParsed,
                                buttonColorParsed.copy(alpha = 0.7f)
                            )
                        )
                    }
                )
                .border(
                    width = 2.dp,
                    color = buttonColorParsed,
                    shape = if (buttonStyle == ScanButtonStyle.HEX) {
                        androidx.compose.foundation.shape.GenericShape { size, _ ->
                            val path = Path()
                            val centerX = size.width / 2
                            val centerY = size.height / 2
                            val radius = minOf(size.width, size.height) / 2
                            for (i in 0..5) {
                                val angle = Math.toRadians((i * 60 - 30).toDouble())
                                val x = centerX + (radius * cos(angle)).toFloat()
                                val y = centerY + (radius * sin(angle)).toFloat()
                                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                            }
                            path.close()
                        }
                    } else CircleShape
                )
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isScanning) Icons.Default.Stop else Icons.Default.PlayArrow,
                contentDescription = if (isScanning) "Stop" else "Start",
                tint = colors.textPrimary,
                modifier = Modifier.size(buttonSizePx / 2)
            )
        }
    }
}

@Composable
fun BottomNavigationBar(
    currentRoute: String,
    onNavigate: (String) -> Unit,
    colors: BlueMeanieColors
) {
    val items = listOf(
        Triple("RADAR", Icons.Default.Radar, "radar"),
        Triple("FEED", Icons.Default.List, "feed"),
        Triple("HEATMAP", Icons.Default.Map, "heatmap"),
        Triple("INTEL", Icons.Default.Shield, "intel"),
        Triple("BTC", Icons.Default.Paid, "btc"),
        Triple("GEAR", Icons.Default.Settings, "gear")
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.surface)
            .padding(vertical = 8.dp)
            .navigationBarsPadding(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEach { (label, icon, route) ->
            val isActive = currentRoute == route
            val infiniteTransition = rememberInfiniteTransition(label = "nav_$route")
            val glowAlpha by infiniteTransition.animateFloat(
                initialValue = 0.4f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(800, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "glow_$route"
            )
            Column(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (isActive) colors.primary.copy(alpha = 0.1f)
                        else androidx.compose.ui.graphics.Color.Transparent
                    )
                    .clickable { onNavigate(route) }
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isActive) colors.primary.copy(alpha = glowAlpha) else colors.textMuted,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = label,
                    fontSize = 9.sp,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                    color = if (isActive) colors.primary else colors.textMuted,
                    fontFamily = FontFamily.Monospace
                )
                if (isActive) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Box(
                        modifier = Modifier
                            .size(20.dp, 2.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(
                                        colors.primary.copy(alpha = 0f),
                                        colors.primary,
                                        colors.primary.copy(alpha = 0f)
                                    )
                                ),
                                RoundedCornerShape(1.dp)
                            )
                    )
                }
            }
        }
    }
}

@Composable
fun AxonAlertOverlay(
    device: ScannedDevice,
    onDismiss: () -> Unit,
    colors: BlueMeanieColors
) {
    val infiniteTransition = rememberInfiniteTransition(label = "alert")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(500),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(5000)
        onDismiss()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.8f))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .scale(scale)
                .size(300.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(colors.surface)
                .border(3.dp, colors.danger, RoundedCornerShape(16.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Alert",
                    tint = colors.danger,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "⚠️ AXON DETECTED ⚠️",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.danger
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = device.name ?: "Unknown Device",
                    fontSize = 16.sp,
                    color = colors.textPrimary
                )
                Text(
                    text = device.macAddress,
                    fontSize = 14.sp,
                    color = colors.textSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Confidence: ${device.confidence}%",
                    fontSize = 14.sp,
                    color = colors.warning
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Tap to dismiss",
                    fontSize = 12.sp,
                    color = colors.textMuted
                )
            }
        }
    }
}

@Composable
fun DeviceDetailSheet(
    device: ScannedDevice,
    onDismiss: () -> Unit,
    onMarkThreat: (Boolean) -> Unit,
    colors: BlueMeanieColors
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = colors.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = device.name ?: "Unknown Device",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Row {
                        Text(
                            text = device.deviceType.name,
                            fontSize = 12.sp,
                            color = when {
                                device.isAxon -> colors.danger
                                device.isThreat -> colors.danger
                                else -> colors.textMuted
                            }
                        )
                        if (device.isAxon) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "● AXON",
                                fontSize = 12.sp,
                                color = colors.danger
                            )
                        }
                    }
                }
                // Hidden easter egg - braille
                Text(
                    text = "⠃⠍⠆⠒",
                    fontSize = 16.sp,
                    color = colors.textMuted.copy(alpha = 0.1f)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // MAC Address
            DetailRow(label = "MAC ADDRESS", value = device.macAddress, colors = colors)

            // OUI
            device.oui?.let {
                DetailRow(label = "OUI", value = it, colors = colors)
            }

            // RSSI
            DetailRow(label = "SIGNAL STRENGTH", value = "${device.rssi} dBm", colors = colors)

            // Confidence
            if (device.isAxon) {
                DetailRow(label = "CONFIDENCE", value = "${device.confidence}%", colors = colors)
            }

            // First Seen
            DetailRow(
                label = "FIRST SEEN",
                value = formatTimestamp(device.firstSeen),
                colors = colors
            )

            // Last Seen
            DetailRow(
                label = "LAST SEEN",
                value = formatTimestamp(device.lastSeen),
                colors = colors
            )

            // Detection Count
            DetailRow(label = "DETECTIONS", value = device.detectionCount.toString(), colors = colors)

            Spacer(modifier = Modifier.height(24.dp))

            // Mark as Threat Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Mark as Threat",
                    fontSize = 14.sp,
                    color = colors.textPrimary
                )
                Switch(
                    checked = device.isThreat,
                    onCheckedChange = onMarkThreat,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = colors.danger,
                        checkedTrackColor = colors.danger.copy(alpha = 0.3f)
                    )
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun DetailRow(
    label: String,
    value: String,
    colors: BlueMeanieColors
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = colors.textMuted
        )
        Text(
            text = value,
            fontSize = 12.sp,
            color = colors.textPrimary,
            fontFamily = FontFamily.Monospace
        )
    }
}

private fun formatDuration(millis: Long): String {
    val seconds = (millis / 1000) % 60
    val minutes = (millis / (1000 * 60)) % 60
    val hours = millis / (1000 * 60 * 60)
    return if (hours > 0) {
        String.format("%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}

private fun formatTimestamp(timestamp: Long): String {
    val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
    return sdf.format(java.util.Date(timestamp))
}