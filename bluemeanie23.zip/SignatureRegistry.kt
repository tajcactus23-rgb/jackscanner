package com.bluemeanie.axonscanner.data.detection

import java.util.regex.Pattern

/**
 * SignatureRegistry — generalises BlueMeanie's Axon-only matcher into a
 * data-driven, multi-category BLE signature engine.
 *
 * TRUST RULE (matches the app's core promise): a candidate only becomes a real
 * detection when it matches a signature flagged `verified = true`. Unverified /
 * research signatures are evaluated only when the caller opts in, and are
 * surfaced as "candidate / unconfirmed", never as a confirmed detection.
 * This keeps "every detection is a real detection" intact while still letting
 * you expand coverage into new hardware classes.
 */

enum class DetectionCategory { BODY_CAM, TASER, FLEX, TRACKER, FACE_SCANNER, GENERIC }

/** Per-axis contribution to the confidence score (0..100 total). */
data class Weights(
    val oui: Int = 40,
    val name: Int = 35,
    val serviceUuid: Int = 25,
    val companyId: Int = 20
)

data class DeviceSignature(
    val category: DetectionCategory,
    val label: String,
    val ouiPrefixes: List<String> = emptyList(),      // "AA:BB:CC" upper-case
    val namePatterns: List<Pattern> = emptyList(),
    val serviceUuids: List<String> = emptyList(),      // full 128-bit, upper-case
    val companyIds: List<Int> = emptyList(),           // BLE SIG company IDs (manufacturer data key)
    val weights: Weights = Weights(),
    val minConfidence: Int = 40,
    val verified: Boolean = false                      // false = research/candidate only
)

data class DetectionResult(
    val matched: Boolean,
    val confirmed: Boolean,          // matched AND verified signature
    val category: DetectionCategory,
    val label: String,
    val confidence: Int
) {
    companion object {
        val NONE = DetectionResult(false, false, DetectionCategory.GENERIC, "Unknown", 0)
    }
}

object SignatureRegistry {

    private fun ci(s: String) = Pattern.compile(s, Pattern.CASE_INSENSITIVE)

    // ── VERIFIED: ported from the shipping BleRepository (Axon body-worn kit) ──
    private val axon = listOf(
        DeviceSignature(
            category = DetectionCategory.BODY_CAM,
            label = "Axon Body-Worn",
            ouiPrefixes = listOf("00:25:DF", "FC:A9:E8", "A4:34:D9", "00:1A:7D", "F4:5E:AB"),
            namePatterns = listOf(ci("AXON"), ci("AXON_BODY"), ci("AXON_CAMERA"), ci("AXON_FLEX")),
            serviceUuids = listOf("0000FE00-0000-1000-8000-00805F9B34FB"),
            companyIds = listOf(0x00, 0x25, 0xDF, 0xFC, 0xA9, 0xE8),
            verified = true
        )
    )

    // ── VERIFIED (public): consumer trackers. These are the real, documented
    //    counter-surveillance signal — "is an AirTag / SmartTag following me".
    //    NOTE: company-ID matches are BROAD (every Apple device shares 0x004C),
    //    so company weight is low and name/service UUID carry the match.
    private val trackers = listOf(
        DeviceSignature(
            category = DetectionCategory.TRACKER,
            label = "Apple Find My / AirTag",
            companyIds = listOf(0x004C),               // Apple, Inc. (SIG-assigned, public)
            weights = Weights(oui = 20, name = 25, serviceUuid = 25, companyId = 10),
            minConfidence = 45, verified = true
        ),
        DeviceSignature(
            category = DetectionCategory.TRACKER,
            label = "Tile Tracker",
            serviceUuids = listOf(                      // 0xFEED / 0xFEEC assigned to Tile, Inc. (public)
                "0000FEED-0000-1000-8000-00805F9B34FB",
                "0000FEEC-0000-1000-8000-00805F9B34FB"
            ),
            namePatterns = listOf(ci("Tile")),
            weights = Weights(oui = 20, name = 25, serviceUuid = 40, companyId = 10),
            minConfidence = 40, verified = true
        ),
        DeviceSignature(
            category = DetectionCategory.TRACKER,
            label = "Samsung SmartTag",
            serviceUuids = listOf("0000FD5A-0000-1000-8000-00805F9B34FB"), // Samsung (public)
            companyIds = listOf(0x0075),               // Samsung Electronics (public)
            namePatterns = listOf(ci("Smart *Tag")),
            weights = Weights(oui = 20, name = 25, serviceUuid = 35, companyId = 15),
            minConfidence = 40, verified = true
        )
    )

    // ── RESEARCH (verified = false): covert surveillance / BLE face-ID scanners.
    //    I have NOT hard-coded OUIs/UUIDs here because I can't verify real ones,
    //    and unverified signatures would create false detections. Fill these from
    //    YOUR OWN captures, then flip verified = true once confirmed:
    //
    //      1. Capture in a known environment (nRF Connect, Wireshark+BLE sniffer,
    //         or your existing scan log export).
    //      2. Record: MAC OUI, adv name, 128-bit service UUIDs, manufacturer
    //         company ID + payload shape.
    //      3. Cross-check the OUI against the IEEE OUI registry to confirm vendor.
    //      4. Confirm the same signature across multiple independent sightings
    //         before trusting it.
    //
    //    Until then these sit as schema placeholders and never fire a detection.
    private val faceScannerResearch = listOf(
        DeviceSignature(
            category = DetectionCategory.FACE_SCANNER,
            label = "Face-ID Scanner (unconfirmed template)",
            ouiPrefixes = emptyList(),   // TODO: add confirmed OUI(s)
            namePatterns = emptyList(),  // TODO: add confirmed adv-name pattern(s)
            serviceUuids = emptyList(),  // TODO: add confirmed 128-bit UUID(s)
            companyIds = emptyList(),    // TODO: add confirmed company ID(s)
            verified = false
        )
    )

    val all: List<DeviceSignature> = axon + trackers + faceScannerResearch

    /**
     * Evaluate a candidate against the registry.
     * @param includeUnverified if true, research signatures can produce a
     *        `matched=true, confirmed=false` result (surface as "candidate").
     */
    fun evaluate(
        oui: String?,
        name: String?,
        serviceUuids: List<String>,
        manufacturerData: Map<Int, ByteArray>,
        includeUnverified: Boolean = false
    ): DetectionResult {
        var best = DetectionResult.NONE
        for (sig in all) {
            if (!sig.verified && !includeUnverified) continue
            val score = score(sig, oui, name, serviceUuids, manufacturerData)
            if (score >= sig.minConfidence && score > best.confidence) {
                best = DetectionResult(
                    matched = true,
                    confirmed = sig.verified,
                    category = sig.category,
                    label = sig.label,
                    confidence = score
                )
            }
        }
        return best
    }

    private fun score(
        sig: DeviceSignature,
        oui: String?,
        name: String?,
        serviceUuids: List<String>,
        manufacturerData: Map<Int, ByteArray>
    ): Int {
        var c = 0
        oui?.uppercase()?.let { o -> if (sig.ouiPrefixes.any { o.startsWith(it) }) c += sig.weights.oui }
        name?.let { n -> if (sig.namePatterns.any { it.matcher(n).find() }) c += sig.weights.name }
        if (sig.serviceUuids.isNotEmpty() &&
            serviceUuids.any { u -> sig.serviceUuids.any { it.equals(u, ignoreCase = true) } })
            c += sig.weights.serviceUuid
        if (sig.companyIds.isNotEmpty() && manufacturerData.keys.any { it in sig.companyIds })
            c += sig.weights.companyId
        return c.coerceIn(0, 100)
    }
}

/*
─────────────────────────────────────────────────────────────────────────────
DROP-IN: replace detectAxonDevice(...) in BleRepository with:

    val result = SignatureRegistry.evaluate(
        oui = oui,
        name = name,
        serviceUuids = serviceUuids,
        manufacturerData = manufacturerData,
        includeUnverified = settings.showCandidateDevices   // user toggle, default false
    )
    // result.confirmed == your old `isAxon` semantics (real detection)
    // result.category  -> map to DeviceType (add TRACKER, FACE_SCANNER to the enum)
    // result.confidence, result.label as before

Add to DeviceType enum: TRACKER, FACE_SCANNER.
Keep user-facing "detections" wording. Candidates (confirmed=false) should read
as "unconfirmed candidate", visually distinct from confirmed detections, so the
trust promise holds.
─────────────────────────────────────────────────────────────────────────────
*/
