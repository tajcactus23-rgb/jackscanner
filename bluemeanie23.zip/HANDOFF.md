# BlueMeanie Android BLE Scanner — Consolidated Handoff

## Current State (July 17, 2026 — 4:30 AM)

### Critical Issue
**All 16 radar canvas components render blank on device.** Root cause: `C:\Android\platform-tools\adb.exe` is ARM-compiled (not Windows), so every install command failed silently for 4+ days. Real Windows adb is at `C:\temp\platform-tools\platform-tools\adb.exe`.

### What Works
- App launches, UI scales correctly (density fix applied)
- Bottom nav touch detection fixed (pointer-events guard + clamp)
- Permissions declared (battery, overlay, wake_lock)
- 15 radar styles wired in Gear selector
- Music engine + 3 tracks bundled
- Console hook added to MainActivity for JS error logging

### What's Broken
- Canvas rendering: OrreryCore, TacticalReticle, CityGridTracker, FluidParticle, SirenRepel, WaveformMesh, CrystallineBloom, MagneticVortex, LiquidMorphing, PlasmaStorm, VoidCollapse, AuroraDrift, QuantumEntangle (all 16 blank)
- Touch animations not firing (likely same root cause)
- Selection circle in Gear doesn't appear

### Likely Root Causes
1. **Canvas context acquisition failing** — `getContext("2d")` may be returning null
2. **Component not mounting** — React state/ref issues in DetectionModules.jsx
3. **CSS scaling still breaking canvas dimensions** — clamps may not be applying correctly
4. **WebView not injecting CSS custom properties** — --android-safe-bottom not reaching JS

### Next Steps
1. **Verify adb connection** using real Windows binary at `C:\temp\platform-tools\platform-tools\adb.exe`
2. **Pull real JS console errors** via logcat BMJS tag
3. **Fix the actual error** (will be revealed by step 2)
4. **Rebuild + install to a015 CMF (rooted, available)**
5. **Field test**

### File Locations
- **Web source:** `C:\Users\PCVR\Documents\Codex\2026-06-21\task-bar-is-freezing-because-of\work\blue-latest-zip\work\base44\src\`
- **Android wrapper:** `C:\Users\PCVR\Documents\Codex\2026-06-21\task-bar-is-freezing-because-of\work\blue-latest-zip\work\android-wrapper\`
- **APK outputs:** `C:\Users\PCVR\Documents\Codex\2026-06-21\task-bar-is-freezing-because-of\work\outputs\`
- **Gradle:** `C:\Users\PCVR\Documents\Codex\2026-06-21\task-bar-is-freezing-because-of\work\tools\gradle-8.9\bin\gradle.bat`
- **Android SDK:** `C:\Android\` (but adb.exe is corrupted; use `C:\temp\platform-tools\platform-tools\adb.exe`)

### Key Files Modified This Session
- `MainActivity.java` — console hook added, density fix applied, permissions declared
- `DetectionModules.jsx` — 16 canvas components added (all blank, not rendering)
- `BottomNav.jsx` — pointer-events guard + clamp applied
- `index.css` — safe-area clamps applied
- `GearTab.jsx` — 15 radar styles wired
- `AndroidManifest.xml` — 3 permissions added (battery, overlay, wake_lock)
- `bgMusic.js` — singleton engine with shuffle/autoplay/background-play toggle
- `BgMusicPlayer.jsx` — UI + controls

### Device Info
- **Test device:** moto G84 (ZT322K6P5C) — 1080x2400, 400dpi (2.5x factor)
- **Field test device:** a015 CMF (rooted, connected, available now)
- **App package:** com.jackscanner (main), com.bluemeanie.axonscanner (emulator variant)

### Known Good Fallback
`BlueMeanie-1.8.3-hardening-vanity-eta-production-debug.apk` (July 2 build) — radar renders, fully functional, can be installed as fallback while fixing new visuals.

### Video Reference Frames (Still Pending)
Need to build sets 2 + 3 visuals (6 more canvas components). Video refs uploaded but frame extraction broke mid-analysis. Remaining work:
- Set 2: Compass Dial + Waveform Analyzer
- Set 3: Network Graph + Spectral Cascade

---

**Status:** Ready for dedicated project. Next action: verify adb connection + pull real console errors.
