package com.bluemeanie.axonscanner.util

import kotlin.math.ln
import kotlin.math.pow

/**
 * VanityEstimator — statistically honest ETA for a brute-force vanity generator
 * (vanity BLE/MAC address, or any prefix/suffix search over a fixed charset).
 *
 * Model: each generated candidate independently matches the target with
 * probability p = 1 / charsetSize^matchLen. Successes are geometric, which is
 * MEMORYLESS: the expected number of *remaining* attempts is always 1/p, no
 * matter how many you've already burned. So we never show a fake countdown that
 * ticks to zero — we show expected attempts, cumulative probability so far, and
 * the median ("50% by") which is what people actually feel.
 */
object VanityEstimator {

    /** Charset sizes for common vanity targets. */
    enum class Charset(val size: Int) {
        HEX(16),            // 0-9 A-F  (typical MAC / hex address, case-insensitive)
        BASE32(32),
        ALNUM_LOWER(36),    // 0-9 a-z
        ALNUM_MIXED(62),    // 0-9 a-z A-Z
        BASE58(58)
    }

    data class Estimate(
        val matchLen: Int,
        val charsetSize: Int,
        val perCandidateProb: Double,     // p
        val expectedAttempts: Double,     // 1/p  (also = expected *remaining* at any time)
        val medianAttempts: Double,       // 50% chance by here
        val p90Attempts: Double,          // 90% chance by here
        val expectedSeconds: Double,      // expectedAttempts / rate
        val medianSeconds: Double,
        val p90Seconds: Double
    )

    /**
     * @param matchLen   number of chosen characters that must match (prefix + suffix combined)
     * @param charset    alphabet the match is drawn from
     * @param rate       candidates generated per second (measure this live from the generator)
     */
    fun estimate(matchLen: Int, charset: Charset, rate: Double): Estimate {
        require(matchLen >= 0) { "matchLen must be >= 0" }
        val safeRate = if (rate <= 0.0) 1.0 else rate
        val expected = charset.size.toDouble().pow(matchLen)   // Double avoids Long overflow at high matchLen
        val p = 1.0 / expected
        val median = attemptsForProbability(p, 0.50)
        val p90 = attemptsForProbability(p, 0.90)
        return Estimate(
            matchLen = matchLen,
            charsetSize = charset.size,
            perCandidateProb = p,
            expectedAttempts = expected,
            medianAttempts = median,
            p90Attempts = p90,
            expectedSeconds = expected / safeRate,
            medianSeconds = median / safeRate,
            p90Seconds = p90 / safeRate
        )
    }

    /** Cumulative probability of at least one hit after [attempts] generations. */
    fun probabilityAfter(p: Double, attempts: Long): Double =
        1.0 - (1.0 - p).pow(attempts.toDouble())

    /** How many attempts to reach [targetProb] (e.g. 0.5, 0.9). */
    fun attemptsForProbability(p: Double, targetProb: Double): Double {
        if (p <= 0.0) return Double.POSITIVE_INFINITY
        // n = ln(1 - target) / ln(1 - p)
        return ln(1.0 - targetProb) / ln(1.0 - p)
    }

    /**
     * Per-character cost table: what each additional matched character does to the
     * search. Drives your "estimated time per character" UI — each row is the cost
     * of a target of that length at the given live [rate].
     */
    fun perCharacterTable(maxLen: Int, charset: Charset, rate: Double): List<Estimate> =
        (1..maxLen).map { estimate(it, charset, rate) }

    // ---- formatting helpers for the HUD ----

    fun humanCount(n: Double): String = when {
        n.isInfinite() -> "∞"
        n < 1_000 -> n.toLong().toString()
        n < 1e6 -> "%.1fK".format(n / 1e3)
        n < 1e9 -> "%.1fM".format(n / 1e6)
        n < 1e12 -> "%.1fB".format(n / 1e9)
        n < 1e15 -> "%.1fT".format(n / 1e12)
        else -> "%.1e".format(n)
    }

    fun humanDuration(seconds: Double): String {
        if (seconds.isInfinite()) return "∞"
        if (seconds < 1) return "<1s"
        var s = seconds.toLong()
        val d = s / 86_400; s %= 86_400
        val h = s / 3_600;  s %= 3_600
        val m = s / 60;     s %= 60
        return when {
            d > 365 -> "%.1f yr".format(d / 365.0)
            d > 0 -> "${d}d ${h}h"
            h > 0 -> "${h}h ${m}m"
            m > 0 -> "${m}m ${s}s"
            else -> "${s}s"
        }
    }
}

/*
─────────────────────────────────────────────────────────────────────────────
LIVE PROGRESS (drop into your generator coroutine)

data class VanityProgress(
    val attempts: Long,
    val rate: Double,            // rolling candidates/sec
    val cumulativeProb: Double,  // 0..1  → drive a progress ring / bar
    val etaExpected: String,     // VanityEstimator.humanDuration(est.expectedSeconds)
    val etaMedian: String
)

// inside your search loop, ~4x/sec:
val est = VanityEstimator.estimate(matchLen, charset, liveRate)
emit(VanityProgress(
    attempts        = attemptsSoFar,
    rate            = liveRate,
    cumulativeProb  = VanityEstimator.probabilityAfter(est.perCandidateProb, attemptsSoFar),
    etaExpected     = VanityEstimator.humanDuration(est.expectedSeconds),
    etaMedian       = VanityEstimator.humanDuration(est.medianSeconds)
))

UI copy that stays honest:
  "≈ ${humanCount(est.expectedAttempts)} gens  ·  50% by ${etaMedian}  ·  ${(cumulativeProb*100).toInt()}% covered"
Each extra matched char multiplies the search by the charset size (×16 for HEX).
─────────────────────────────────────────────────────────────────────────────
*/
