package com.jackscanner.ui.screens.home

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jackscanner.data.preferences.PreferencesManager
import com.jackscanner.domain.model.Detection
import com.jackscanner.domain.model.ScannerStatus
import com.jackscanner.domain.repository.DetectionRepository
import com.jackscanner.service.BleScanService
import com.jackscanner.service.ScanController
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val isScanning: Boolean = false,
    val scannerStatus: ScannerStatus = ScannerStatus.IDLE,
    val detectionsToday: Int = 0,
    val lastDetection: Detection? = null,
    val recentDetections: List<Detection> = emptyList(),
    val detectedCount: Int = 0,
    val bluetoothActive: Boolean = false,
    val communityActivity: Int = 0,
    val needsBluetoothEnable: Boolean = false,
    val needsPermissions: Boolean = false,
    val scanError: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val detectionRepository: DetectionRepository,
    private val preferencesManager: PreferencesManager,
    private val scanController: ScanController,
    @ApplicationContext private val context: Context
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()
    
    private var bluetoothCheckCallback: (() -> Unit)? = null
    private var permissionsCheckCallback: (() -> Unit)? = null
    
    init {
        loadData()
        observeScannerStatus()
    }
    
    private fun loadData() {
        viewModelScope.launch {
            detectionRepository.getRecentDetections(10).collect { detections ->
                _uiState.update { state ->
                    state.copy(
                        recentDetections = detections,
                        lastDetection = detections.firstOrNull()
                    )
                }
            }
        }
        
        viewModelScope.launch {
            try {
                val count = detectionRepository.getDetectionCountToday()
                _uiState.update { it.copy(detectionsToday = count) }
            } catch (e: Exception) {
                _uiState.update { it.copy(detectionsToday = 0) }
            }
        }
    }
    
    private fun observeScannerStatus() {
        viewModelScope.launch {
            while (true) {
                val isRunning = BleScanService.isRunning
                val count = BleScanService.detectedCount
                _uiState.update { state ->
                    state.copy(
                        isScanning = isRunning,
                        scannerStatus = if (isRunning) ScannerStatus.SCANNING else ScannerStatus.IDLE,
                        detectedCount = count
                    )
                }
                kotlinx.coroutines.delay(1000)
            }
        }
    }
    
    fun setCallbacks(onBluetoothCheck: () -> Unit, onPermissionsCheck: () -> Unit) {
        bluetoothCheckCallback = onBluetoothCheck
        permissionsCheckCallback = onPermissionsCheck
    }
    
    fun toggleScanning() {
        // Clear any previous errors
        _uiState.update { it.copy(scanError = null) }

        if (BleScanService.isRunning) {
            try {
                val result = scanController.stopScanning()
                if (!result) {
                    _uiState.update { it.copy(scanError = "Failed to stop scanning") }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(scanError = "Error stopping scan: ${e.message}") }
            }
            return
        }

        // Check Bluetooth availability safely
        val bluetoothManager = try {
            context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        } catch (e: Exception) {
            null
        }
        
        val bluetoothAdapter = bluetoothManager?.adapter

        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            _uiState.update { it.copy(needsBluetoothEnable = true, scanError = "Bluetooth is not available or disabled") }
            bluetoothCheckCallback?.invoke()
            return
        }

        // Check all required permissions
        val requiredPermissions = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Manifest.permission.BLUETOOTH_SCAN)
                add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }

        val missingPermissions = requiredPermissions.filter {
            try {
                context.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
            } catch (e: Exception) {
                true
            }
        }

        if (missingPermissions.isNotEmpty()) {
            _uiState.update { it.copy(needsPermissions = true, scanError = "Required permissions not granted") }
            permissionsCheckCallback?.invoke()
            return
        }

        // All checks passed - start scanning
        try {
            val result = scanController.startScanning()
            if (!result) {
                _uiState.update { it.copy(scanError = "Failed to start scanning service") }
            }
        } catch (e: Exception) {
            _uiState.update { it.copy(scanError = "Error starting scanner: ${e.message}") }
        }
    }
    
    fun onBluetoothEnabled() {
        _uiState.update { it.copy(needsBluetoothEnable = false, scanError = null) }
        toggleScanning()
    }
    
    fun onPermissionsGranted() {
        _uiState.update { it.copy(needsPermissions = false) }
    }
    
    fun onPermissionDenied() {
        _uiState.update { it.copy(needsPermissions = true) }
    }
    
    fun refreshData() {
        loadData()
    }

    fun clearScanError() {
        _uiState.update { it.copy(scanError = null) }
    }
}

data class PermissionStep(
    val permission: String?,
    val title: String,
    val description: String,
    val rationale: String
)