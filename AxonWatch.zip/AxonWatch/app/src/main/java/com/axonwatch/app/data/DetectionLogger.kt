package com.axonwatch.app.data

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class DetectionLogger(context: Context) {
    private val appContext = context.applicationContext
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private val detectionsLog by lazy { File(appContext.filesDir, "detections.log") }
    private val copsLog by lazy { File(appContext.filesDir, "cops.log") }

    fun logDetection(detection: Detection) {
        val timeStr = dateFormat.format(Date(detection.timestamp))
        val line = ">>>>>>>> POLICE DETECTED: ${detection.macAddress} (Time: $timeStr) [RSSI: ${detection.rssi}dBm]"
        detectionsLog.appendText("$line\n")
        copsLog.appendText("$line (Logged: $timeStr)\n")
    }

    fun logScanStart() {
        val timeStr = dateFormat.format(Date())
        detectionsLog.appendText(">>>> Scan started. $timeStr\n")
    }

    fun logScanStop() {
        val timeStr = dateFormat.format(Date())
        detectionsLog.appendText(">>>> Scan complete. $timeStr\n")
    }

    fun readDetectionsLog(): String = if (detectionsLog.exists()) detectionsLog.readText() else "No detections yet."
    fun readCopsLog(): String = if (copsLog.exists()) copsLog.readText() else "No cop encounters logged."

    fun clearLogs() {
        detectionsLog.writeText("")
        copsLog.writeText("")
    }
}
