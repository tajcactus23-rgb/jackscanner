package com.axonwatch.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.axonwatch.app.MainActivity
import com.axonwatch.app.R
import com.axonwatch.app.data.Detection
import com.axonwatch.app.data.DetectionLogger
import kotlinx.coroutines.*

class BleScanService : Service() {
    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val CHANNEL_ID = "axonwatch_channel"
        const val NOTIFICATION_ID = 101
        const val ALERT_NOTIFICATION_ID = 666
        const val AXON_OUI = "00:25:DF"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var logger: DetectionLogger
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var isScanning = false
    private var totalAxonDetections = 0
    private var wakeLock: PowerManager.WakeLock? = null

    private val alertSounds = listOf(
        R.raw.alert_this_is_the_police,
        R.raw.alert_get_on_the_ground,
        R.raw.alert_get_your_hands_behind,
        R.raw.alert_stop_or_ill_shoot,
        R.raw.alert_lay_on_the_ground,
        R.raw.alert_stop_resisting_1,
        R.raw.alert_stop_resisting_2,
        R.raw.alert_we_have_you_surrounded,
        R.raw.alert_police_officer_custom
    )

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            result ?: return
            val device = result.device
            val address = device.address?.uppercase() ?: "UNKNOWN"
            val name = device.name ?: "Unknown Device"
            val rssi = result.rssi
            val isAxon = address.startsWith(AXON_OUI)

            val detection = Detection(macAddress = address, name = name, rssi = rssi, isAxon = isAxon)

            if (isAxon) {
                totalAxonDetections++
                logger.logDetection(detection)
                triggerAlert(detection)
            }
            sendBroadcast(Intent("SCAN_RESULT").apply { putExtra("detection", detection) })
        }
        override fun onBatchScanResults(results: MutableList<ScanResult>?) {
            results?.forEach { onScanResult(0, it) }
        }
        override fun onScanFailed(errorCode: Int) {
            sendBroadcast(Intent("SCAN_STATUS").apply { putExtra("status", "Scan failed: code $errorCode") })
        }
    }

    override fun onCreate() {
        super.onCreate()
        logger = DetectionLogger(this)
        val bm = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bm.adapter
        createNotificationChannel()
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AxonWatch::ScanWakeLock")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startScanning()
            ACTION_STOP -> stopScanning()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startScanning() {
        if (isScanning) return
        isScanning = true
        wakeLock?.acquire(10 * 60 * 1000L)
        val notification = buildForegroundNotification("Scanning for Axon devices...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        logger.logScanStart()
        val scanner = bluetoothAdapter?.bluetoothLeScanner ?: run {
            updateNotification("Bluetooth LE Scanner unavailable")
            return
        }
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner.startScan(null, settings, scanCallback)

        serviceScope.launch {
            while (isScanning) {
                delay(12000)
                if (isScanning) {
                    scanner.stopScan(scanCallback)
                    delay(500)
                    scanner.startScan(null, settings, scanCallback)
                    logger.logScanStop()
                    logger.logScanStart()
                }
            }
        }
        sendStatus("Scanning started...")
    }

    private fun stopScanning() {
        isScanning = false
        bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback)
        logger.logScanStop()
        serviceScope.cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun triggerAlert(detection: Detection) {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION") getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION") vibrator.vibrate(1000)
        }

        try {
            val randomSound = alertSounds.random()
            val mp = MediaPlayer.create(this, randomSound)
            mp?.setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build())
            mp?.setVolume(1.0f, 1.0f)
            mp?.setOnCompletionListener { it.release() }
            mp?.start()
        } catch (_: Exception) { }

        val alertNotification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("🚨 LAW ENFORCEMENT NEARBY")
            .setContentText("Axon device: ${detection.macAddress}")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setVibrate(longArrayOf(0, 500, 200, 500, 200, 500))
            .build()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(ALERT_NOTIFICATION_ID, alertNotification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "AxonWatch Alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Police equipment detection alerts"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500)
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AxonWatch Active")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, buildForegroundNotification(text))
    }

    private fun sendStatus(status: String) {
        sendBroadcast(Intent("SCAN_STATUS").apply { putExtra("status", status) })
    }

    override fun onDestroy() {
        super.onDestroy()
        stopScanning()
    }
}
