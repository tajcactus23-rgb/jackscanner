package com.axonwatch.app.ui.screens

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.axonwatch.app.data.Detection
import com.axonwatch.app.service.BleScanService
import com.axonwatch.app.ui.theme.*
import com.axonwatch.app.viewmodel.ScanViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: ScanViewModel) {
    val context = LocalContext.current
    val isScanning by viewModel.isScanning
    val status by viewModel.statusText
    val devices by remember { derivedStateOf { viewModel.devices } }
    val axonCount by viewModel.axonCount
    val totalScans by viewModel.totalScans
    val alertMode by viewModel.alertMode
    var showLogs by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(600, easing = EaseInOutQuad), RepeatMode.Reverse),
        label = "pulse"
    )

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        if (perms.entries.all { it.value } && !isScanning) startService(context)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        NeuralBackground(alertMode = alertMode)

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text("AXONWATCH", fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black, letterSpacing = 3.sp,
                            color = if (alertMode) AlertRed else NeonCyan)
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Black.copy(alpha = 0.7f),
                        titleContentColor = NeonCyan
                    ),
                    actions = {
                        IconButton(onClick = { showLogs = true }) {
                            Icon(Icons.Default.Description, "Logs",
                                tint = if (alertMode) AlertRed else NeonCyan)
                        }
                    }
                )
            },
            containerColor = Color.Transparent
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0A0A).copy(alpha = 0.85f)),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp,
                        if (alertMode) AlertRed.copy(alpha = 0.5f) else NeonCyan.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier.size(100.dp)
                                .scale(if (isScanning || alertMode) pulse else 1f)
                                .background(
                                    brush = Brush.radialGradient(
                                        colors = if (alertMode) listOf(AlertRed, AlertRed.copy(alpha = 0.3f), Color.Transparent)
                                        else if (isScanning) listOf(NeonCyan, NeonCyan.copy(alpha = 0.3f), Color.Transparent)
                                        else listOf(Color.Gray, Color.Gray.copy(alpha = 0.3f), Color.Transparent)
                                    ), shape = RoundedCornerShape(50)
                                ), contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (alertMode) Icons.Default.Warning
                                else if (isScanning) Icons.Default.Radar else Icons.Default.RadioButtonUnchecked,
                                contentDescription = "Status", tint = Color.Black, modifier = Modifier.size(48.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        AnimatedVisibility(visible = alertMode) {
                            Text("⚠️ LAW ENFORCEMENT DETECTED ⚠️", color = AlertRed,
                                fontWeight = FontWeight.Black, fontSize = 18.sp,
                                fontFamily = FontFamily.Monospace, modifier = Modifier.padding(bottom = 8.dp))
                        }
                        Text(
                            if (alertMode) "AXON DEVICE IN RANGE" else if (isScanning) "SCANNING ACTIVE" else "STANDBY",
                            color = if (alertMode) AlertRed else if (isScanning) NeonCyan else Color.Gray,
                            fontWeight = FontWeight.Bold, fontSize = 22.sp, fontFamily = FontFamily.Monospace
                        )
                        Text(status, color = Color.Gray, fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 4.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            StatBox("AXON HITS", axonCount.toString(), if (alertMode) AlertRed else NeonCyan)
                            StatBox("DEVICES", devices.size.toString(), DeepPurple)
                            StatBox("SCANS", totalScans.toString(), SynapticGold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = {
                            if (isScanning) {
                                context.stopService(Intent(context, BleScanService::class.java))
                                viewModel.isScanning.value = false
                            } else {
                                checkAndRequestPermissions(context, permissionLauncher) { startService(context) }
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isScanning) Color(0xFF330000).copy(alpha = 0.9f)
                            else NeonCyan.copy(alpha = 0.9f)
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(if (isScanning) "■ STOP SCAN" else "▶ START SCAN",
                            color = if (isScanning) AlertRed else DarkBg,
                            fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace,
                            fontSize = 14.sp, modifier = Modifier.padding(vertical = 8.dp))
                    }
                    OutlinedButton(
                        onClick = { viewModel.clearDevices() },
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Gray),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.Gray.copy(alpha = 0.5f))
                    ) {
                        Text("CLEAR", fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 8.dp))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text("NEARBY BLE DEVICES", color = Color.Gray.copy(alpha = 0.7f),
                    fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp, modifier = Modifier.align(Alignment.Start))
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(devices, key = { it.timestamp + it.macAddress.hashCode() }) { device ->
                        AnimatedVisibility(visible = true, enter = scaleIn(tween(300)) + fadeIn(tween(300))) {
                            DeviceCard(device)
                        }
                    }
                }
            }
        }
    }

    if (showLogs) {
        LogsDialog(viewModel) { showLogs = false }
    }
}

@Composable
fun StatBox(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = color, fontWeight = FontWeight.Black, fontSize = 26.sp, fontFamily = FontFamily.Monospace)
        Text(label, color = Color.DarkGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
    }
}

@Composable
fun DeviceCard(device: Detection) {
    val bgColor = if (device.isAxon) Color(0xFF220000).copy(alpha = 0.9f) else Color(0xFF0A0A0A).copy(alpha = 0.8f)
    val borderColor = if (device.isAxon) AlertRed.copy(alpha = 0.6f) else NeonCyan.copy(alpha = 0.15f)
    val textColor = if (device.isAxon) AlertRed else NeuralWhite

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(device.name ?: "Unknown Device", color = textColor,
                    fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                Text(device.macAddress, color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (device.isAxon) {
                    Box(modifier = Modifier.background(AlertRed.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)) {
                        Text("AXON", color = AlertRed, fontWeight = FontWeight.Black,
                            fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }
                val rssiColor = when {
                    device.rssi > -60 -> Color(0xFF00FF00)
                    device.rssi > -80 -> Color(0xFFFFFF00)
                    else -> Color(0xFFFF4444)
                }
                Text("${device.rssi}dBm", color = rssiColor,
                    fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun LogsDialog(viewModel: ScanViewModel, onDismiss: () -> Unit) {
    var logs by remember { mutableStateOf("") }
    var showCopsLog by remember { mutableStateOf(false) }
    LaunchedEffect(showCopsLog) {
        val (det, cops) = viewModel.getLogs()
        logs = if (showCopsLog) cops else det
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0A0A0A).copy(alpha = 0.95f),
        title = {
            Text("SYSTEM LOGS", color = NeonCyan, fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        },
        text = {
            Column {
                Row {
                    TextButton(onClick = {
                        showCopsLog = false
                        val (det, _) = viewModel.getLogs()
                        logs = det
                    }) {
                        Text("detections.log", color = if (!showCopsLog) NeonCyan else Color.Gray,
                            fontFamily = FontFamily.Monospace)
                    }
                    TextButton(onClick = {
                        showCopsLog = true
                        val (_, cops) = viewModel.getLogs()
                        logs = cops
                    }) {
                        Text("cops.log", color = if (showCopsLog) NeonCyan else Color.Gray,
                            fontFamily = FontFamily.Monospace)
                    }
                }
                Box(modifier = Modifier.heightIn(max = 400.dp)
                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(12.dp)) {
                    Text(logs, color = Color.Gray, fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { viewModel.clearLogs(); logs = "Logs cleared." }) {
                Text("CLEAR", color = AlertRed, fontFamily = FontFamily.Monospace)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CLOSE", color = NeuralWhite, fontFamily = FontFamily.Monospace)
            }
        }
    )
}

private fun startService(context: Context) {
    ContextCompat.startForegroundService(context,
        Intent(context, BleScanService::class.java).apply { action = BleScanService.ACTION_START })
}

private fun checkAndRequestPermissions(
    context: Context,
    launcher: androidx.activity.compose.ManagedActivityResultLauncher<Array<String>, Map<String, Boolean>>,
    onGranted: () -> Unit
) {
    val permissions = mutableListOf<String>()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        permissions.add(Manifest.permission.BLUETOOTH_SCAN)
        permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        permissions.add(Manifest.permission.BLUETOOTH)
        permissions.add(Manifest.permission.BLUETOOTH_ADMIN)
    }
    permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        permissions.add(Manifest.permission.POST_NOTIFICATIONS)
    }
    val missing = permissions.filter {
        ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
    }
    if (missing.isEmpty()) {
        val btAdapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (btAdapter?.isEnabled == false) {
            context.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        } else {
            onGranted()
        }
    } else {
        launcher.launch(missing.toTypedArray())
    }
}
