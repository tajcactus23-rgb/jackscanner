package com.axonwatch.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import com.axonwatch.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.*
import kotlin.random.Random

private const val NODE_COUNT = 50
private const val CONNECTION_DISTANCE = 280f
private const val TRAVELER_COUNT = 8

private data class NeuralNode(
    var x: Float, var y: Float,
    val baseX: Float, val baseY: Float,
    val size: Float, val phase: Float, val speed: Float,
    var pulseOffset: Float = 0f
)

private data class Traveler(
    var fromNode: Int, var toNode: Int,
    var progress: Float, val speed: Float, val color: Color
)

private data class TouchNode(var x: Float, var y: Float, var alpha: Float, var radius: Float)

@Composable
fun NeuralBackground(modifier: Modifier = Modifier, alertMode: Boolean = false) {
    var canvasSize by remember { mutableStateOf(androidx.compose.ui.geometry.Size.Zero) }
    var touchPos by remember { mutableStateOf<Offset?>(null) }

    val nodes = remember { mutableStateListOf<NeuralNode>() }
    val travelers = remember { mutableStateListOf<Traveler>() }
    val touchNodes = remember { mutableStateListOf<TouchNode>() }

    LaunchedEffect(canvasSize) {
        if (canvasSize.width > 0 && nodes.isEmpty()) {
            repeat(NODE_COUNT) {
                val x = Random.nextFloat() * canvasSize.width
                val y = Random.nextFloat() * canvasSize.height
                nodes.add(NeuralNode(x, y, x, y, Random.nextFloat() * 3f + 2f,
                    Random.nextFloat() * 2f * PI.toFloat(), Random.nextFloat() * 0.3f + 0.1f))
            }
            repeat(TRAVELER_COUNT) {
                val from = Random.nextInt(NODE_COUNT)
                var to = Random.nextInt(NODE_COUNT)
                while (to == from) to = Random.nextInt(NODE_COUNT)
                travelers.add(Traveler(from, to, Random.nextFloat(),
                    Random.nextFloat() * 0.008f + 0.003f,
                    listOf(NeonCyan, DeepPurple, SynapticGold).random()))
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "neural")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 2f * PI.toFloat(),
        animationSpec = infiniteRepeatable(tween(20000, easing = LinearEasing), RepeatMode.Restart),
        label = "time"
    )

    LaunchedEffect(time) {
        nodes.forEachIndexed { _, node ->
            val driftX = sin(time * node.speed + node.phase) * 30f
            val driftY = cos(time * node.speed * 0.7f + node.phase) * 30f
            node.x = node.baseX + driftX
            node.y = node.baseY + driftY
            touchPos?.let { touch ->
                val dx = touch.x - node.x
                val dy = touch.y - node.y
                val dist = sqrt(dx * dx + dy * dy)
                if (dist < 200f && dist > 1f) {
                    val force = (200f - dist) / 200f * 15f
                    node.x += (dx / dist) * force
                    node.y += (dy / dist) * force
                }
            }
            node.pulseOffset = sin(time * 2f + node.phase) * 2f
        }
        travelers.forEach { traveler ->
            traveler.progress += traveler.speed
            if (traveler.progress >= 1f) {
                traveler.fromNode = traveler.toNode
                var newTo = Random.nextInt(nodes.size)
                while (newTo == traveler.fromNode) newTo = Random.nextInt(nodes.size)
                traveler.toNode = newTo
                traveler.progress = 0f
            }
        }
        val it = touchNodes.iterator()
        while (it.hasNext()) {
            val tn = it.next()
            tn.alpha -= 0.015f
            tn.radius += 1.5f
            if (tn.alpha <= 0f) it.remove()
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    touchNodes.add(TouchNode(offset.x, offset.y, 1f, 5f))
                }
            }
            .pointerInput(Unit) {
                detectDragGestures(onDrag = { change, _ -> touchPos = change.position },
                    onDragEnd = { touchPos = null })
            }
    ) {
        canvasSize = this.size
        if (nodes.isEmpty()) return@Canvas
        drawRect(if (alertMode) Color(0xFF1A0000) else DarkBg)

        // Connections
        for (i in nodes.indices) {
            for (j in i + 1 until nodes.size) {
                val n1 = nodes[i]; val n2 = nodes[j]
                val dx = n2.x - n1.x; val dy = n2.y - n1.y
                val dist = sqrt(dx * dx + dy * dy)
                if (dist < CONNECTION_DISTANCE) {
                    val alpha = (1f - dist / CONNECTION_DISTANCE) * 0.3f
                    val lineColor = if (alertMode) AlertRed.copy(alpha = alpha) else NeonCyan.copy(alpha = alpha)
                    drawLine(lineColor, Offset(n1.x, n1.y), Offset(n2.x, n2.y), strokeWidth = 1f)
                }
            }
        }

        // Travelers
        travelers.forEach { t ->
            if (t.fromNode < nodes.size && t.toNode < nodes.size) {
                val n1 = nodes[t.fromNode]; val n2 = nodes[t.toNode]
                val midX = (n1.x + n2.x) / 2f
                val midY = (n1.y + n2.y) / 2f - 50f * sin(t.progress * PI.toFloat())
                val x = (1 - t.progress) * (1 - t.progress) * n1.x + 2 * (1 - t.progress) * t.progress * midX + t.progress * t.progress * n2.x
                val y = (1 - t.progress) * (1 - t.progress) * n1.y + 2 * (1 - t.progress) * t.progress * midY + t.progress * t.progress * n2.y
                drawCircle(t.color, radius = 4f, center = Offset(x, y), alpha = 0.9f)
                drawCircle(t.color.copy(alpha = 0.3f), radius = 8f, center = Offset(x, y))
            }
        }

        // Nodes
        nodes.forEach { node ->
            val nodeColor = if (alertMode) AlertRed else NeonCyan
            val glowRadius = node.size + node.pulseOffset + 4f
            drawCircle(nodeColor.copy(alpha = 0.15f), radius = glowRadius * 3f, center = Offset(node.x, node.y))
            drawCircle(nodeColor.copy(alpha = 0.4f), radius = glowRadius, center = Offset(node.x, node.y))
            drawCircle(if (alertMode) Color.White else NeuralWhite, radius = node.size, center = Offset(node.x, node.y))
        }

        // Touch nodes
        touchNodes.forEach { tn ->
            drawCircle(SynapticGold.copy(alpha = tn.alpha * 0.5f), radius = tn.radius, center = Offset(tn.x, tn.y), style = Stroke(width = 2f))
            drawCircle(SynapticGold.copy(alpha = tn.alpha), radius = tn.radius * 0.3f, center = Offset(tn.x, tn.y))
        }

        // Vignette
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f)),
                center = Offset(size.width / 2, size.height / 2),
                radius = size.width * 0.8f
            )
        )
    }
}
