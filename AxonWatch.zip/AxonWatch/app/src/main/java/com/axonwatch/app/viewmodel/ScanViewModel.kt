package com.axonwatch.app.viewmodel

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import com.axonwatch.app.data.Detection
import com.axonwatch.app.data.DetectionLogger

class ScanViewModel(application: Application) : AndroidViewModel(application) {
    val isScanning = mutableStateOf(false)
    val statusText = mutableStateOf("Ready")
    val devices = mutableStateListOf<Detection>()
    val axonCount = mutableStateOf(0)
    val totalScans = mutableStateOf(0)
    val alertMode = mutableStateOf(false)

    private val logger = DetectionLogger(application)

    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "SCAN_RESULT" -> {
                    @Suppress("DEPRECATION")
                    val detection = intent.getParcelableExtra<Detection>("detection")
                    detection?.let {
                        devices.add(0, it)
                        if (it.isAxon) {
                            axonCount.value++
                            triggerAlertMode()
                        }
                        if (devices.size > 100) devices.removeLast()
                    }
                }
                "SCAN_STATUS" -> {
                    statusText.value = intent.getStringExtra("status") ?: "Scanning..."
                    if (statusText.value.contains("started")) {
                        isScanning.value = true
                        totalScans.value++
                    }
                }
            }
        }
    }

    init {
        val filter = IntentFilter().apply {
            addAction("SCAN_RESULT")
            addAction("SCAN_STATUS")
        }
        application.registerReceiver(scanReceiver, filter, Context.RECEIVER_EXPORTED)
    }

    private fun triggerAlertMode() {
        alertMode.value = true
        Handler(Looper.getMainLooper()).postDelayed({ alertMode.value = false }, 5000)
    }

    fun clearDevices() {
        devices.clear()
        axonCount.value = 0
    }

    fun getLogs(): Pair<String, String> = logger.readDetectionsLog() to logger.readCopsLog()
    fun clearLogs() = logger.clearLogs()

    override fun onCleared() {
        super.onCleared()
        getApplication<Application>().unregisterReceiver(scanReceiver)
    }
}
