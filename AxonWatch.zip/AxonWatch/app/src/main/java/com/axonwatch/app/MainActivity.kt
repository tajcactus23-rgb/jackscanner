package com.axonwatch.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.axonwatch.app.ui.screens.MainScreen
import com.axonwatch.app.ui.theme.AxonWatchTheme
import com.axonwatch.app.viewmodel.ScanViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: ScanViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AxonWatchTheme {
                MainScreen(viewModel = viewModel)
            }
        }
    }
}
