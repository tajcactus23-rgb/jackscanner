package com.axonwatch.app.ui.theme

import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00F0FF)
val AlertRed = Color(0xFFFF0040)
val DeepPurple = Color(0xFFBD00FF)
val SynapticGold = Color(0xFFFFD700)
val NeuralWhite = Color(0xFFF0F0F0)
val DarkBg = Color(0xFF000000)
val CardBg = Color(0xFF0A0A0A)
val CardBorder = Color(0xFF1A1A1A)
