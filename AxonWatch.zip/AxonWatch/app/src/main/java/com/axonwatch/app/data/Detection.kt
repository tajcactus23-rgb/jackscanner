package com.axonwatch.app.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Detection(
    val macAddress: String,
    val name: String?,
    val rssi: Int,
    val isAxon: Boolean,
    val timestamp: Long = System.currentTimeMillis()
) : Parcelable
