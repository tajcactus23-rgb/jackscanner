# AxonWatch

**Neural Network UI + BLE Police Equipment Detector for Android**

A combined Android app merging the detection logic from `PoliceDetector` and `lookout.py` into a single native Kotlin application with a living neural network background, glassmorphism UI, and randomized police audio alerts.

---

## Features

- **Neural Network Background**: Real-time animated Canvas with 50 drifting nodes, bezier connections, traveling light packets, touch gravity wells, and tap pulse effects. Turns red during alerts.
- **BLE Axon Detection**: Scans for Bluetooth Low Energy devices with OUI `00:25:DF` (Axon / Taser International). 12-second scan loop.
- **9 Randomized Police Audio Alerts**: Plays a random police command audio clip on detection:
  - "This is the police"
  - "Get on the ground"
  - "Get your hands behind your back"
  - "Stop or I'll shoot"
  - "Lay on the ground"
  - "Stop resisting" (2 variants)
  - "We have you surrounded"
  - "Police officer custom"
- **Dual Logging**: Writes to both `detections.log` (police.py style) and `cops.log` (lookout.py style).
- **Alert System**: High-priority notification + 1000ms vibration + random audio + red neural pulse.
- **Glassmorphism UI**: Dark cyberpunk theme with neon cyan, electric violet, and synaptic gold accents.
- **Foreground Service**: Runs with wake lock and auto-restarts scan every 12 seconds.

---

## Build Options

### Option 1: Android Studio (Recommended)
1. Open this folder in Android Studio Hedgehog (2023.1.1) or newer.
2. Let Gradle sync.
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. APK will be in `app/build/outputs/apk/debug/app-debug.apk`.

### Option 2: Build Wizard GUI
```bash
python build_wizard.py
```
A dark-themed tkinter GUI will guide you through setting the Android SDK path and building.

### Option 3: Command Line
```bash
# Set SDK path in local.properties first
# Linux/macOS:
./gradlew assembleDebug

# Windows:
gradlew.bat assembleDebug
```

---

## Requirements

- Android Studio Hedgehog+ or Gradle 8.4+
- Android SDK API 34
- Minimum Android 8.0 (API 26) on device
- Bluetooth Low Energy hardware
- Location permission (required for BLE scanning on Android)

---

## ⚠️ Important Limitation

Android 6+ randomizes BLE MAC addresses for privacy. On stock Android, you may not see the real `00:25:DF` OUI of unpaired devices. The app will still show **all nearby BLE devices** so you can inspect them manually. For guaranteed OUI detection, root access or a custom ROM may be required.

---

## Install on Device

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

Or transfer the APK to your phone and install it.

---

## Credits

- `PoliceDetector` by omtoi101
- `lookout.py` by judcrandall
- Audio clips from various police vocal packs
