#!/usr/bin/env python3
"""
AxonWatch APK Build Wizard
A GUI tool to build the AxonWatch Android APK with neural UI and police audio alerts.
"""

import os
import sys
import subprocess
import platform
import threading
import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
from pathlib import Path

class AxonWatchBuilder:
    def __init__(self, root):
        self.root = root
        self.root.title("AxonWatch APK Build Wizard")
        self.root.geometry("900x700")
        self.root.configure(bg="#0A0A0A")
        self.root.minsize(800, 600)

        # Dark theme colors
        self.bg_color = "#0A0A0A"
        self.fg_color = "#00F0FF"
        self.accent_color = "#BD00FF"
        self.alert_color = "#FF0040"
        self.card_bg = "#111111"
        self.text_color = "#F0F0F0"

        self.project_dir = Path(__file__).parent.resolve()
        self.sdk_path = tk.StringVar()
        self.build_type = tk.StringVar(value="debug")
        self.status = tk.StringVar(value="Ready to build")
        self.progress = tk.DoubleVar(value=0)

        self.setup_ui()
        self.detect_sdk()

    def setup_ui(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame", background=self.bg_color)
        style.configure("TLabel", background=self.bg_color, foreground=self.text_color, font=("Consolas", 10))
        style.configure("TButton", background=self.fg_color, foreground="black", font=("Consolas", 10, "bold"))
        style.configure("TEntry", fieldbackground=self.card_bg, foreground=self.text_color)
        style.configure("TCombobox", fieldbackground=self.card_bg, foreground=self.text_color)
        style.configure("Horizontal.TProgressbar", background=self.fg_color, troughcolor=self.card_bg)

        # Header
        header = tk.Frame(self.root, bg=self.bg_color)
        header.pack(fill="x", padx=20, pady=10)

        tk.Label(header, text="⚡ AXONWATCH BUILD WIZARD ⚡",
                 bg=self.bg_color, fg=self.fg_color,
                 font=("Consolas", 20, "bold")).pack()
        tk.Label(header, text="Neural Network UI + Police Audio Alert APK Builder",
                 bg=self.bg_color, fg=self.accent_color,
                 font=("Consolas", 11)).pack()

        # Main content
        content = tk.Frame(self.root, bg=self.bg_color)
        content.pack(fill="both", expand=True, padx=20, pady=10)

        # Left panel - Configuration
        left = tk.Frame(content, bg=self.card_bg, bd=1, relief="solid")
        left.pack(side="left", fill="both", expand=True, padx=(0, 10))

        tk.Label(left, text=" CONFIGURATION ", bg=self.card_bg, fg=self.fg_color,
                 font=("Consolas", 12, "bold")).pack(anchor="w", padx=15, pady=(15, 10))

        # SDK Path
        sdk_frame = tk.Frame(left, bg=self.card_bg)
        sdk_frame.pack(fill="x", padx=15, pady=5)
        tk.Label(sdk_frame, text="Android SDK Path:", bg=self.card_bg, fg=self.text_color,
                 font=("Consolas", 10)).pack(anchor="w")
        sdk_input = tk.Frame(sdk_frame, bg=self.card_bg)
        sdk_input.pack(fill="x", pady=(5, 0))
        tk.Entry(sdk_input, textvariable=self.sdk_path, font=("Consolas", 10),
                 bg="#1A1A1A", fg=self.text_color, insertbackground=self.fg_color,
                 relief="flat", highlightthickness=1, highlightcolor=self.fg_color).pack(side="left", fill="x", expand=True)
        tk.Button(sdk_input, text="Browse", command=self.browse_sdk,
                  bg=self.fg_color, fg="black", font=("Consolas", 9, "bold"),
                  relief="flat", cursor="hand2").pack(side="right", padx=(5, 0))

        # Build Type
        type_frame = tk.Frame(left, bg=self.card_bg)
        type_frame.pack(fill="x", padx=15, pady=10)
        tk.Label(type_frame, text="Build Type:", bg=self.card_bg, fg=self.text_color,
                 font=("Consolas", 10)).pack(anchor="w")
        tk.Radiobutton(type_frame, text="Debug (faster, unsigned)", variable=self.build_type,
                       value="debug", bg=self.card_bg, fg=self.text_color,
                       selectcolor=self.fg_color, activebackground=self.card_bg,
                       font=("Consolas", 10)).pack(anchor="w", pady=2)
        tk.Radiobutton(type_frame, text="Release (slower, needs signing)", variable=self.build_type,
                       value="release", bg=self.card_bg, fg=self.text_color,
                       selectcolor=self.fg_color, activebackground=self.card_bg,
                       font=("Consolas", 10)).pack(anchor="w", pady=2)

        # Features info
        info_frame = tk.Frame(left, bg=self.card_bg)
        info_frame.pack(fill="x", padx=15, pady=10)
        tk.Label(info_frame, text="FEATURES BUNDLED:", bg=self.card_bg, fg=self.accent_color,
                 font=("Consolas", 10, "bold")).pack(anchor="w")
        features = [
            "✓ Neural network animated background (Canvas + physics)",
            "✓ BLE Axon OUI detection (00:25:DF)",
            "✓ 9 randomized police audio alerts",
            "✓ Dual logging (detections.log + cops.log)",
            "✓ Haptic vibration + notification alerts",
            "✓ Glassmorphism UI with dark cyberpunk theme",
            "✓ 12-second scan loop (lookout.py behavior)",
            "✓ Foreground service with wake lock"
        ]
        for feat in features:
            tk.Label(info_frame, text=feat, bg=self.card_bg, fg=self.text_color,
                     font=("Consolas", 9)).pack(anchor="w", pady=1)

        # Action buttons
        btn_frame = tk.Frame(left, bg=self.card_bg)
        btn_frame.pack(fill="x", padx=15, pady=(10, 15))
        tk.Button(btn_frame, text="▶ BUILD APK", command=self.start_build,
                  bg=self.fg_color, fg="black", font=("Consolas", 12, "bold"),
                  relief="flat", cursor="hand2", padx=20, pady=8).pack(side="left", padx=(0, 10))
        tk.Button(btn_frame, text="☰ Open Project Folder", command=self.open_project,
                  bg=self.accent_color, fg="white", font=("Consolas", 10, "bold"),
                  relief="flat", cursor="hand2", padx=15, pady=8).pack(side="left")

        # Right panel - Console output
        right = tk.Frame(content, bg=self.card_bg, bd=1, relief="solid")
        right.pack(side="right", fill="both", expand=True)

        tk.Label(right, text=" BUILD CONSOLE ", bg=self.card_bg, fg=self.fg_color,
                 font=("Consolas", 12, "bold")).pack(anchor="w", padx=15, pady=(15, 10))

        self.console = scrolledtext.ScrolledText(
            right, bg="#000000", fg="#00F0FF", font=("Consolas", 9),
            insertbackground=self.fg_color, relief="flat", wrap="word"
        )
        self.console.pack(fill="both", expand=True, padx=15, pady=(0, 10))
        self.console.config(state="disabled")

        # Status bar
        status_bar = tk.Frame(self.root, bg=self.card_bg)
        status_bar.pack(fill="x", side="bottom", padx=20, pady=(0, 10))

        self.status_label = tk.Label(status_bar, textvariable=self.status,
                                     bg=self.card_bg, fg=self.fg_color,
                                     font=("Consolas", 10, "bold"))
        self.status_label.pack(side="left")

        self.progress_bar = ttk.Progressbar(status_bar, variable=self.progress,
                                            maximum=100, mode="determinate",
                                            length=200, style="Horizontal.TProgressbar")
        self.progress_bar.pack(side="right")

        self.log("AxonWatch Build Wizard initialized.")
        self.log(f"Project directory: {self.project_dir}")
        self.log("Set your Android SDK path and click BUILD APK.")

    def detect_sdk(self):
        """Auto-detect Android SDK path."""
        possible_paths = []
        system = platform.system()

        if system == "Windows":
            possible_paths = [
                os.path.expandvars(r"%LOCALAPPDATA%\Android\Sdk"),
                r"C:\Users\%USERNAME%\AppData\Local\Android\Sdk",
                r"C:\Program Files\Android\android-sdk",
            ]
        elif system == "Darwin":
            possible_paths = [
                os.path.expanduser("~/Library/Android/sdk"),
                "/usr/local/share/android-sdk",
            ]
        else:  # Linux
            possible_paths = [
                os.path.expanduser("~/Android/Sdk"),
                "/usr/lib/android-sdk",
                "/opt/android-sdk",
            ]

        for path in possible_paths:
            expanded = os.path.expandvars(path)
            if os.path.isdir(expanded) and os.path.exists(os.path.join(expanded, "platform-tools")):
                self.sdk_path.set(expanded)
                self.log(f"Auto-detected SDK: {expanded}")
                return

        self.log("Android SDK not auto-detected. Please browse to it.")

    def browse_sdk(self):
        path = filedialog.askdirectory(title="Select Android SDK Directory")
        if path:
            self.sdk_path.set(path)
            self.log(f"SDK path set to: {path}")

    def open_project(self):
        import webbrowser
        path = str(self.project_dir)
        if platform.system() == "Windows":
            os.startfile(path)
        elif platform.system() == "Darwin":
            subprocess.run(["open", path])
        else:
            subprocess.run(["xdg-open", path])

    def log(self, message):
        self.console.config(state="normal")
        self.console.insert("end", f"> {message}\n")
        self.console.see("end")
        self.console.config(state="disabled")

    def start_build(self):
        sdk = self.sdk_path.get().strip()
        if not sdk or not os.path.isdir(sdk):
            messagebox.showerror("Error", "Please set a valid Android SDK path.")
            return

        # Write local.properties
        local_props = self.project_dir / "local.properties"
        with open(local_props, "w") as f:
            f.write(f"sdk.dir={sdk}\n")
        self.log(f"Wrote local.properties with SDK path.")

        # Start build thread
        self.status.set("Building...")
        self.progress.set(10)
        threading.Thread(target=self.run_build, daemon=True).start()

    def run_build(self):
        try:
            gradlew = "gradlew.bat" if platform.system() == "Windows" else "./gradlew"
            gradlew_path = self.project_dir / gradlew

            if not gradlew_path.exists():
                self.root.after(0, lambda: self.log("ERROR: gradlew not found. Make sure Gradle wrapper is present."))
                self.root.after(0, lambda: self.status.set("Build failed"))
                self.root.after(0, lambda: self.progress.set(0))
                return

            build_cmd = [str(gradlew_path), f"assemble{self.build_type.get().capitalize()}"]
            self.root.after(0, lambda: self.log(f"Running: {' '.join(build_cmd)}"))
            self.root.after(0, lambda: self.progress.set(30))

            env = os.environ.copy()
            env["ANDROID_SDK_ROOT"] = self.sdk_path.get()
            env["ANDROID_HOME"] = self.sdk_path.get()

            process = subprocess.Popen(
                build_cmd,
                cwd=str(self.project_dir),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                env=env,
                shell=(platform.system() == "Windows")
            )

            for line in process.stdout:
                self.root.after(0, lambda l=line.strip(): self.log(l))

            process.wait()
            self.root.after(0, lambda: self.progress.set(90))

            if process.returncode == 0:
                apk_dir = self.project_dir / f"app/build/outputs/apk/{self.build_type.get()}"
                self.root.after(0, lambda: self.log("\n✅ BUILD SUCCESSFUL!"))
                self.root.after(0, lambda: self.log(f"APK location: {apk_dir}"))
                self.root.after(0, lambda: self.status.set("Build complete"))
                self.root.after(0, lambda: self.progress.set(100))
                self.root.after(0, lambda: messagebox.showinfo(
                    "Build Complete",
                    f"APK built successfully!\n\nLocation:\n{apk_dir}\n\nInstall on your Android device with:\nadb install app-debug.apk"
                ))
            else:
                self.root.after(0, lambda: self.log("\n❌ BUILD FAILED"))
                self.root.after(0, lambda: self.status.set("Build failed"))
                self.root.after(0, lambda: self.progress.set(0))

        except Exception as e:
            self.root.after(0, lambda: self.log(f"ERROR: {str(e)}"))
            self.root.after(0, lambda: self.status.set("Error"))
            self.root.after(0, lambda: self.progress.set(0))

def main():
    root = tk.Tk()
    app = AxonWatchBuilder(root)
    root.mainloop()

if __name__ == "__main__":
    main()
